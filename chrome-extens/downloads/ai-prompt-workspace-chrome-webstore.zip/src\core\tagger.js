const STOP = new Set([
  'the','and','or','to','of','in','on','for','with','a','an','is','are','be','as','at','by','from','it','this','that',
  '我','我们','你','你们','的','了','和','与','及','在','中','是','有','无','把','被','而','并','及其','以及'
]);

function normalize(s) {
  return s.toLowerCase();
}

export function suggestTags(content, max = 7) {
  const text = normalize(content);
  const words = text.split(/[^a-zA-Z0-9\u4e00-\u9fa5]+/).filter(Boolean);
  const freq = new Map();
  for (const w of words) {
    if (STOP.has(w)) continue;
    if (w.length < 2) continue;
    freq.set(w, (freq.get(w) || 0) + 1);
  }
  const special = new Set();
  if (text.includes('midjourney') || text.includes('mj')) special.add('MJ');
  if (text.includes('stable diffusion') || text.includes('sd')) special.add('SD');
  if (text.includes('二次元')) special.add('二次元');
  const sorted = Array.from(freq.entries()).sort((a, b) => b[1] - a[1]).map(([w]) => w);
  const out = [];
  for (const s of special) out.push(s);
  for (const w of sorted) {
    if (out.length >= max) break;
    if (!out.includes(w)) out.push(w);
  }
  return out;
}
