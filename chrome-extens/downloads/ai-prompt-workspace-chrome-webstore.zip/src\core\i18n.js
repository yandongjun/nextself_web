import { getUIState, setUIState } from './storage.js';

const ZH = 'zh';
const EN = 'en';

const messages = {
  zh: {
    popupTitle: 'AI Prompt Workspace',
    popupSearchPlaceholder: '搜索提示词 / 标签',
    openOptions: '进入管理页',
    noResults: '当前筛选无结果。',
    clearFilters: '清空筛选',
    popupReadError: '读取本地数据失败：{message}',
    popupReadErrorShort: '数据读取失败',
    hiddenResults: '新增{count}条被隐藏，点此显示',
    filteredBy: '筛选：{value}',
    searchedBy: '搜索：{value}',
    unnamedPrompt: '未命名',
    syncing: '同步中',
    pendingSync: '待同步',
    blocked: '已阻塞',
    aiProcessing: 'AI处理中',
    aiQuotaExceeded: 'AI超额',
    aiFailed: 'AI失败',
    copy: '复制',
    copied: '已复制',
    copyFailed: '复制失败',
    pinToContextMenu: '加入右键',
    unpinFromContextMenu: '移出右键',
    contextMenuPinned: '已加入右键粘贴',
    contextMenuUnpinned: '已移出右键粘贴',
    contextMenuOverflowRemoved: '右键最多保留5条，已自动移除最早加入的一条',
    allCategories: '全部分类',
    optionsTitle: 'AI Prompt Workspace - 全局搜索',
    newPrompt: '+ 新增',
    import: '导入',
    export: '导出',
    batchAction: '批量操作',
    tagManager: '标签管理',
    account: '账户',
    backToPopup: '回到Popup',
    backendAddress: '后端地址',
    save: '保存',
    email: '邮箱',
    password: '密码',
    login: '登录',
    register: '注册',
    logout: '退出',
    searchFullPlaceholder: '搜索标题/内容/标签 | 多关键词用空格分隔 | #匹配标签 @匹配标题',
    allTypes: '全部类型',
    usageStatus: '使用状态',
    recent7Days: '最近7天',
    recent30Days: '最近30天',
    favorite: '收藏',
    createdAt: '创建时间',
    today: '今天',
    thisWeek: '本周',
    thisMonth: '本月',
    thisYear: '本年',
    sortRule: '排序规则',
    recentUse: '最近使用',
    usageFrequency: '使用频率',
    reset: '重置',
    clearTags: '清空标签',
    deleteSelected: '删除选中',
    addTagToSelected: '为选中加标签',
    selectedCount: '已选 {count} 条',
    clickToToggle: '点击展开/收起',
    edit: '编辑',
    delete: '删除',
    deletePromptConfirm: '删除当前提示词？此操作不可撤销。',
    resultSummary: '结果数：{resultCount}/{totalCount}{stateText}{hiddenText}',
    hiddenSummary: ' | 新增{count}条被筛选隐藏（点此显示）',
    emptyStorageHint: '未读取到提示词数据。请确认使用 Popup 的“进入管理页”打开，或在扩展程序详情页点击“扩展程序选项”。',
    emptyStorageLine1: '未读取到提示词数据。',
    emptyStorageLine2: '扩展ID：{id}',
    emptyStorageLine3: 'local：{count} 条{error}',
    emptyStorageLine4: 'sync：{count} 条{error}',
    emptyStorageLine5: '建议：关闭当前管理页，用 Popup 的“进入管理页”重新打开；并在扩展程序页面点击“重新加载”。',
    quotaFormat: '额度：{used}/{limit}',
    planSummary: '套餐：{plan} | 状态：{status}',
    planFree: '免费版',
    planPro: '专业版',
    planAnonymous: '游客模式',
    planStatusActive: '有效',
    planStatusAnonymous: '未登录',
    planStatusExpired: '已过期',
    planStatusUnknown: '未知',
    upgradePlan: '升级订阅',
    managePlan: '管理订阅',
    upgradeLoginFirst: '请先注册或登录，再进行升级。',
    upgradeNeedLoginLocal: '检测到当前设备已有本地提示词。请先登录或注册，系统会先绑定匿名数据，再进入支付。',
    upgradeNeedLoginNew: '请先登录或注册账号，再进行订阅。这样我们才能把 Pro 权益准确绑定到你的账户。',
    upgradePreparingBilling: '正在准备支付会话...',
    upgradeClaimingAnonymous: '正在绑定当前设备的匿名数据...',
    upgradeSyncingLocalPrompts: '正在同步本地提示词...',
    upgradeOpenCheckout: '即将打开绑定账户的支付页：{email}',
    upgradeSessionFailed: '创建支付会话失败：{message}',
    billingComingSoon: '支付入口暂未接入，后续将从这里进入结算。',
    billingHintAnonymous: '当前为游客模式，升级前请先注册或登录。',
    billingHintFree: '当前为免费版，最多保存 {limit} 条提示词。',
    billingHintPro: '当前为付费版，可使用更高容量。',
    billingHintExpired: '当前订阅已结束，暂时无法新增提示词。',
    billingUnavailable: '套餐信息暂不可用',
    taxonomyManagerProOnly: '分类管理仅对 Pro 付费用户开放。',
    loggedIn: '已登录：{email}',
    notLoggedIn: '未登录',
    authInvalidInput: '{action}失败：请填写邮箱和密码',
    authEmailExists: '{action}失败：邮箱已注册，请直接登录',
    authUserNotFound: '{action}失败：账号不存在，请先注册',
    authInvalidPassword: '{action}失败：密码错误',
    authUnauthorized: '{action}失败：未授权（请先注册或检查账号密码）',
    authUnknownError: '{action}失败：{message}',
    batchAddTagPrompt: '为选中加标签：',
    importSummary: '导入完成：新增 {imported} 条，跳过重复 {skipped} 条',
    importLimitReached: '（免费版最多保存 {max} 条，请先注册并付费开通更多容量）',
    importCurrentStats: '（当前总数 {total} 条，当前筛选显示 {shown} 条）',
    saveFailed: '保存失败：{message}',
    newPromptTitle: '新增提示词',
    cancel: '取消',
    submit: '提交',
    tagCategoryManager: '标签分类管理',
    addPrimaryTag: '新增一级标签',
    addSecondaryTag: '新增二级标签',
    close: '关闭',
    rename: '重命名',
    renamePrimaryPrompt: '重命名一级标签为：',
    renameSecondaryPrompt: '重命名二级标签为：',
    addPrimaryPrompt: '新增一级标签名称：',
    addSecondaryPrompt: '新增二级标签名称：',
    deletePrimaryConfirm: '删除一级标签“{name}”？该分类下的提示词将移动到“其他”。',
    deleteSecondaryConfirm: '删除标签“{name}”？将从所有提示词中移除该标签。',
    editPromptTitle: '编辑提示词',
    titlePlaceholder: '标题（用于概括提示词作用/角色名称）',
    selectPrimaryTag: '选择一级标签',
    tagPlaceholder: '二级标签/自定义标签（用逗号分隔）',
    preview: '预览',
    optionsInitFailed: '管理页初始化失败：{message}',
    addSelectedPrompt: '新增选中为提示词',
    insertSavedPrompt: '插入已保存提示词',
    noSavedPrompt: '暂无已保存提示词',
    promptAlreadyExists: '已存在该提示词（点击定位）',
    promptAdded: '已添加该提示词',
    promptInserted: '已插入提示词',
    promptNotFound: '未找到要插入的提示词',
    editableNotFound: '未找到可插入的输入框',
    addedToPrompt: '已添加到提示词',
    limitExceeded: '免费版最多保存{max}条提示词，请先注册并付费开通更多容量。',
    networkPending: '网络不可用，已加入待同步队列',
    quotaUsedUp: 'AI额度已用尽',
    unauthorized: '未登录或登录已失效',
    serverRetry: '服务器异常，稍后自动重试',
    syncFailed: '同步失败：{code}',
    syncFailedUnknown: '同步失败：未知错误'
  },
  en: {
    popupTitle: 'AI Prompt Workspace',
    popupSearchPlaceholder: 'Search prompts / tags',
    openOptions: 'Open Manager',
    noResults: 'No results for the current filter.',
    clearFilters: 'Clear Filters',
    popupReadError: 'Failed to read local data: {message}',
    popupReadErrorShort: 'Data Read Failed',
    hiddenResults: '{count} new items are hidden. Click to show.',
    filteredBy: 'Filter: {value}',
    searchedBy: 'Search: {value}',
    unnamedPrompt: 'Untitled',
    syncing: 'Syncing',
    pendingSync: 'Pending',
    blocked: 'Blocked',
    aiProcessing: 'AI Processing',
    aiQuotaExceeded: 'AI Quota Exceeded',
    aiFailed: 'AI Failed',
    copy: 'Copy',
    copied: 'Copied',
    copyFailed: 'Copy Failed',
    pinToContextMenu: 'Add to Context Menu',
    unpinFromContextMenu: 'Remove from Context Menu',
    contextMenuPinned: 'Added to context menu',
    contextMenuUnpinned: 'Removed from context menu',
    contextMenuOverflowRemoved: 'Context menu keeps at most 5 items; the oldest pinned item was removed',
    allCategories: 'All Categories',
    optionsTitle: 'AI Prompt Workspace - Global Search',
    newPrompt: '+ New',
    import: 'Import',
    export: 'Export',
    batchAction: 'Batch',
    tagManager: 'Tags',
    account: 'Account',
    backToPopup: 'Back to Popup',
    backendAddress: 'Backend URL',
    save: 'Save',
    email: 'Email',
    password: 'Password',
    login: 'Log In',
    register: 'Sign Up',
    logout: 'Log Out',
    searchFullPlaceholder: 'Search title/content/tags | Separate keywords by spaces | #tag @title',
    allTypes: 'All Types',
    usageStatus: 'Usage',
    recent7Days: 'Last 7 Days',
    recent30Days: 'Last 30 Days',
    favorite: 'Favorite',
    createdAt: 'Created',
    today: 'Today',
    thisWeek: 'This Week',
    thisMonth: 'This Month',
    thisYear: 'This Year',
    sortRule: 'Sort',
    recentUse: 'Recent Use',
    usageFrequency: 'Usage',
    reset: 'Reset',
    clearTags: 'Clear Tags',
    deleteSelected: 'Delete Selected',
    addTagToSelected: 'Tag Selected',
    selectedCount: '{count} selected',
    clickToToggle: 'Click to expand/collapse',
    edit: 'Edit',
    delete: 'Delete',
    deletePromptConfirm: 'Delete this prompt? This action cannot be undone.',
    resultSummary: 'Results: {resultCount}/{totalCount}{stateText}{hiddenText}',
    hiddenSummary: ' | {count} new items hidden by filters (click to show)',
    emptyStorageHint: 'No prompt data was loaded. Please open this page from Popup "Open Manager", or click "Extension Options" in the extension details page.',
    emptyStorageLine1: 'No prompt data was loaded.',
    emptyStorageLine2: 'Extension ID: {id}',
    emptyStorageLine3: 'local: {count}{error}',
    emptyStorageLine4: 'sync: {count}{error}',
    emptyStorageLine5: 'Suggestion: close this page, reopen it from Popup "Open Manager", then click "Reload" on the extensions page.',
    quotaFormat: 'Quota: {used}/{limit}',
    planSummary: 'Plan: {plan} | Status: {status}',
    planFree: 'Free',
    planPro: 'Pro',
    planAnonymous: 'Guest',
    planStatusActive: 'Active',
    planStatusAnonymous: 'Anonymous',
    planStatusExpired: 'Expired',
    planStatusUnknown: 'Unknown',
    upgradePlan: 'Upgrade',
    managePlan: 'Manage',
    upgradeLoginFirst: 'Please sign in before upgrading.',
    upgradeNeedLoginLocal: 'Local prompts were found on this device. Please sign in first. We will bind anonymous data before checkout.',
    upgradeNeedLoginNew: 'Please sign in or create an account before subscribing so we can bind Pro access to the correct account.',
    upgradePreparingBilling: 'Preparing your checkout session...',
    upgradeClaimingAnonymous: 'Binding anonymous data from this device...',
    upgradeSyncingLocalPrompts: 'Syncing local prompts...',
    upgradeOpenCheckout: 'Opening checkout for account: {email}',
    upgradeSessionFailed: 'Failed to create checkout session: {message}',
    billingComingSoon: 'Billing is not connected yet. Checkout will be available here later.',
    billingHintAnonymous: 'You are in guest mode. Please sign in before upgrading.',
    billingHintFree: 'You are on the free plan with up to {limit} prompts.',
    billingHintPro: 'You are on a paid plan with higher capacity.',
    billingHintExpired: 'Your subscription has ended. New prompts are currently disabled.',
    billingUnavailable: 'Plan information is temporarily unavailable',
    taxonomyManagerProOnly: 'Taxonomy management is available to active Pro users only.',
    loggedIn: 'Signed in: {email}',
    notLoggedIn: 'Not signed in',
    authInvalidInput: '{action} failed: email and password are required',
    authEmailExists: '{action} failed: email already exists, please sign in',
    authUserNotFound: '{action} failed: account not found, please register first',
    authInvalidPassword: '{action} failed: wrong password',
    authUnauthorized: '{action} failed: unauthorized',
    authUnknownError: '{action} failed: {message}',
    batchAddTagPrompt: 'Add a tag to selected prompts:',
    importSummary: 'Import finished: added {imported}, skipped duplicates {skipped}',
    importLimitReached: ' (Free plan supports up to {max} prompts. Please register and pay for more capacity.)',
    importCurrentStats: ' (Current total {total}, visible {shown})',
    saveFailed: 'Save failed: {message}',
    newPromptTitle: 'New Prompt',
    cancel: 'Cancel',
    submit: 'Submit',
    tagCategoryManager: 'Tag Category Manager',
    addPrimaryTag: 'Add Primary Tag',
    addSecondaryTag: 'Add Secondary Tag',
    close: 'Close',
    rename: 'Rename',
    renamePrimaryPrompt: 'Rename primary tag to:',
    renameSecondaryPrompt: 'Rename secondary tag to:',
    addPrimaryPrompt: 'New primary tag name:',
    addSecondaryPrompt: 'New secondary tag name:',
    deletePrimaryConfirm: 'Delete primary tag "{name}"? Prompts under it will be moved to "Other".',
    deleteSecondaryConfirm: 'Delete tag "{name}"? It will be removed from all prompts.',
    editPromptTitle: 'Edit Prompt',
    titlePlaceholder: 'Title (briefly describe the prompt purpose/role)',
    selectPrimaryTag: 'Select Primary Tag',
    tagPlaceholder: 'Secondary/custom tags (comma separated)',
    preview: 'Preview',
    optionsInitFailed: 'Failed to initialize manager page: {message}',
    addSelectedPrompt: 'Save Selection as Prompt',
    insertSavedPrompt: 'Insert Saved Prompt',
    noSavedPrompt: 'No saved prompts',
    promptAlreadyExists: 'Prompt already exists (click to locate)',
    promptAdded: 'Prompt saved',
    promptInserted: 'Prompt inserted',
    promptNotFound: 'Prompt not found',
    editableNotFound: 'No editable input found',
    addedToPrompt: 'Added to prompts',
    limitExceeded: 'Free plan supports up to {max} prompts. Please register and pay for more capacity.',
    networkPending: 'Network unavailable. Added to pending sync queue.',
    quotaUsedUp: 'AI quota has been used up',
    unauthorized: 'Not signed in or session expired',
    serverRetry: 'Server error. Will retry later.',
    syncFailed: 'Sync failed: {code}',
    syncFailedUnknown: 'Sync failed: unknown error'
  }
};

const categoryMessages = {
  zh: {
    工作效率: '工作效率',
    构思创意: '构思创意',
    图像提示词: '图像提示词',
    视频提示词: '视频提示词',
    写作润色: '写作润色',
    对话模拟: '对话模拟',
    开发技术: '开发技术',
    其他: '其他'
  },
  en: {
    工作效率: 'Productivity',
    构思创意: 'Ideation',
    图像提示词: 'Image Prompts',
    视频提示词: 'Video Prompts',
    写作润色: 'Writing',
    对话模拟: 'Conversation',
    开发技术: 'Development',
    其他: 'Other'
  }
};

const tagMessages = {
  zh: {
    会议纪要整理: '会议纪要整理',
    长文摘要: '长文摘要',
    PPT大纲: 'PPT大纲',
    方案编写: '方案编写',
    头脑风暴: '头脑风暴',
    点子生成: '点子生成',
    命名: '命名',
    角度发掘: '角度发掘',
    邮件: '邮件',
    报告: '报告',
    文案: '文案',
    总结: '总结',
    风格改写: '风格改写',
    模拟面试: '模拟面试',
    客户沟通: '客户沟通',
    辩论演练: '辩论演练',
    角色扮演: '角色扮演',
    代码规范: '代码规范',
    产品经理: '产品经理',
    全栈高级工程师: '全栈高级工程师',
    后端工程师: '后端工程师',
    Python: 'Python',
    SQL: 'SQL',
    Prompt: 'Prompt'
  },
  en: {
    会议纪要整理: 'Meeting Notes',
    长文摘要: 'Long-form Summary',
    PPT大纲: 'PPT Outline',
    方案编写: 'Proposal Drafting',
    头脑风暴: 'Brainstorming',
    点子生成: 'Idea Generation',
    命名: 'Naming',
    角度发掘: 'Angle Discovery',
    邮件: 'Email',
    报告: 'Report',
    文案: 'Copywriting',
    总结: 'Summary',
    风格改写: 'Style Rewrite',
    模拟面试: 'Mock Interview',
    客户沟通: 'Client Communication',
    辩论演练: 'Debate Practice',
    角色扮演: 'Role Play',
    代码规范: 'Code Standards',
    产品经理: 'Product Manager',
    全栈高级工程师: 'Senior Full-stack Engineer',
    后端工程师: 'Backend Engineer',
    Python: 'Python',
    SQL: 'SQL',
    Prompt: 'Prompt'
  }
};

const titleMessages = {
  zh: {
    拼写与语法校正器: '拼写与语法校正器',
    魅魔: '魅魔',
    产品经理: '产品经理',
    后端工程师: '后端工程师',
    全栈高级工程师: '全栈高级工程师'
  },
  en: {
    拼写与语法校正器: 'Spelling and Grammar Corrector',
    魅魔: 'Succubus',
    产品经理: 'Product Manager',
    后端工程师: 'Backend Engineer',
    全栈高级工程师: 'Senior Full-stack Engineer'
  }
};

export function normalizeLang(lang) {
  return String(lang || '').toLowerCase() === EN ? EN : ZH;
}

export function detectLang() {
  const value = typeof navigator !== 'undefined' ? String(navigator.language || navigator.languages?.[0] || '') : '';
  return /^zh\b/i.test(value) ? ZH : EN;
}

export async function getLang() {
  const state = await getUIState();
  return normalizeLang(state.lang || detectLang());
}

export async function setLang(lang) {
  const next = normalizeLang(lang);
  await setUIState({ lang: next });
  return next;
}

export function t(lang, key, vars = {}) {
  const code = normalizeLang(lang);
  const dict = messages[code] || messages.zh;
  const fallback = messages.zh[key] || key;
  const text = dict[key] || fallback;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(vars[name] ?? ''));
}

export function categoryLabel(lang, value) {
  const code = normalizeLang(lang);
  return categoryMessages[code]?.[value] || value;
}

export function tagLabel(lang, value, dynamicEn = '') {
  const code = normalizeLang(lang);
  if (code === EN && String(dynamicEn || '').trim()) return String(dynamicEn).trim();
  if (code === EN) return tagMessages.en?.[value] || value;
  return tagMessages.zh?.[value] || value;
}

export function tagSearchTerms(value, dynamicEn = '') {
  const terms = new Set();
  const raw = String(value || '').trim();
  const dyn = String(dynamicEn || '').trim();
  if (raw) terms.add(raw.toLowerCase());
  if (dyn) terms.add(dyn.toLowerCase());
  const zh = tagMessages.zh?.[raw];
  const en = tagMessages.en?.[raw];
  if (zh) terms.add(String(zh).toLowerCase());
  if (en) terms.add(String(en).toLowerCase());
  return Array.from(terms);
}

export function promptTitleLabel(lang, value, dynamicEn = '') {
  const code = normalizeLang(lang);
  const raw = String(value || '').trim();
  if (code === EN && String(dynamicEn || '').trim()) return String(dynamicEn).trim();
  if (code === EN) return titleMessages.en?.[raw] || raw;
  return titleMessages.zh?.[raw] || raw;
}

export function promptTitleSearchTerms(value, dynamicEn = '') {
  const terms = new Set();
  const raw = String(value || '').trim();
  const dyn = String(dynamicEn || '').trim();
  if (raw) terms.add(raw.toLowerCase());
  if (dyn) terms.add(dyn.toLowerCase());
  const zh = titleMessages.zh?.[raw];
  const en = titleMessages.en?.[raw];
  if (zh) terms.add(String(zh).toLowerCase());
  if (en) terms.add(String(en).toLowerCase());
  return Array.from(terms);
}

export function documentLang(lang) {
  return normalizeLang(lang) === EN ? 'en' : 'zh-CN';
}
