import { apiRequest } from './api.js';
import { authFetch } from './auth.js';
import { ensureTaxonomy, getAuthState, getInstallId, getPrompts, setLocalPromptLimit, setTaxonomy, updatePrompt } from './storage.js';
import { getLang, t } from './i18n.js';

function formatAiError(lang, code, status) {
  const c = String(code || '');
  if (c === 'NETWORK_ERROR' || status === 0) return t(lang, 'networkPending');
  if (c === 'QUOTA_EXCEEDED' || status === 402) return t(lang, 'quotaUsedUp');
  if (c === 'UNAUTHORIZED' || status === 401) return t(lang, 'unauthorized');
  if (status >= 500) return t(lang, 'serverRetry');
  if (c) return t(lang, 'syncFailed', { code: c });
  return t(lang, 'syncFailedUnknown');
}

function normalizeTitleText(value, limit = 24) {
  return String(value || '')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/^[`"'[\](){}<>]+|[`"'[\](){}<>]+$/g, '')
    .slice(0, limit)
    .trim();
}

function localLeadPhrase(content) {
  const firstLine = String(content || '').split(/\r?\n/)[0] || '';
  const cleaned = firstLine
    .replace(/^(please|i want you to|请你|请|请对|请将|请为|请根据|请用)\s*/i, '')
    .trim();
  const parts = cleaned.split(/[，,；;|/]/).map((part) => normalizeTitleText(part, 18)).filter(Boolean);
  return parts.find((part) => part.length >= 2) || '';
}

function deriveLocalTitle(content, categories = [], tags = []) {
  const primary = String(categories[0] || '').trim();
  const lead = localLeadPhrase(content);
  const text = String(content || '').toLowerCase();
  if (primary === '图像提示词' || /midjourney|stable diffusion|flux|mj|图像|图片|插画|摄影|cg|3d|建模|渲染|手办|pvc|pixar|迪士尼/.test(text)) {
    if (lead) return normalizeTitleText(`${lead}提示词`, 24);
    return '图像提示词';
  }
  if (primary === '视频提示词' || /视频|短视频|分镜|镜头|运镜|runway|sora|旁白/.test(text)) {
    if (lead) return normalizeTitleText(`${lead}视频提示词`, 24);
    return '视频提示词';
  }
  const firstTag = String((Array.isArray(tags) ? tags[0] : '') || '').trim();
  if (firstTag) return normalizeTitleText(`${firstTag}助手`, 24);
  if (primary && primary !== '其他') return normalizeTitleText(primary, 24);
  return normalizeTitleText(lead, 24) || '通用提示词助手';
}

export async function classifyPrompt(localPromptId, content, options = {}) {
  try {
    const lang = await getLang().catch(() => 'zh');
    const list = options.list || await getPrompts();
    const prev = list.find((p) => p.id === localPromptId) || {};
    const attempt = (typeof prev.syncAttemptCount === 'number' ? prev.syncAttemptCount : 0) + 1;
    await updatePrompt(localPromptId, {
      aiPending: true,
      syncState: 'syncing',
      syncAttemptCount: attempt,
      lastSyncAttemptAt: Date.now()
    });
    const auth = await getAuthState();
    const installId = await getInstallId();
    const taxonomy = await ensureTaxonomy();
    const body = { content, local_prompt_id: localPromptId, install_id: installId, taxonomy };
    const res = auth?.accessToken
      ? await authFetch('/api/prompts/classify', { method: 'POST', body })
      : await apiRequest('/api/prompts/classify', { method: 'POST', body });
    if (res.ok) {
      await setLocalPromptLimit(res.data?.limit);
      const categories = Array.isArray(res.data.categories) ? res.data.categories.filter(Boolean) : [];
      const category = res.data.category || categories[0] || '其他';
      const tags = Array.isArray(res.data.tags) ? res.data.tags : [];
      const tagsEn = Array.isArray(res.data.tags_en) ? res.data.tags_en : (Array.isArray(res.data.tagsEn) ? res.data.tagsEn : []);
      const title = (res.data.title || '').trim();
      const resolvedTitle = title || deriveLocalTitle(content, categories.length ? categories : [category], tags);
      const titleEn = (res.data.title_en || res.data.titleEn || '').trim();
      const translationZh = (res.data.translation_zh || res.data.translationZh || '').trim();

      const patch = {
        serverPromptId: res.data.server_prompt_id,
        title: resolvedTitle,
        category,
        categories: categories.length ? categories : [category],
        tags,
        tagsEn,
        translationZh,
        aiPending: false,
        aiError: '',
        aiQuotaExceeded: false,
        syncState: 'synced',
        syncedAt: Date.now()
      };
      if (titleEn) patch.titleEn = titleEn;

      await updatePrompt(localPromptId, patch);
      if (taxonomy && Array.isArray(taxonomy.categories) && tags.length && categories.length) {
        const next = JSON.parse(JSON.stringify(taxonomy));
        const known = new Set();
        for (const c of next.categories || []) {
          for (const t of (c.children || [])) known.add(t);
        }
        const toAdd = tags.filter((t) => t && !known.has(t));
        if (toAdd.length) {
          const primary = categories[0];
          const catObj = (next.categories || []).find((c) => c.name === primary) || (next.categories || []).find((c) => c.name === '其他');
          catObj.children = Array.from(new Set([...(catObj.children || []), ...toAdd]));
          await setTaxonomy(next);
        }
      }
      return res;
    }
    const err = res.data?.error || String(res.status);
    const blocked = err === 'QUOTA_EXCEEDED' || err === 'UNAUTHORIZED' || res.status === 401 || res.status === 402;
    const pending = res.status === 0 || err === 'NETWORK_ERROR' || res.status >= 500;
    await updatePrompt(localPromptId, {
      aiPending: false,
      aiErrorCode: err,
      aiError: formatAiError(lang, err, res.status),
      aiQuotaExceeded: err === 'QUOTA_EXCEEDED',
      syncState: blocked ? 'blocked' : (pending ? 'pending' : 'pending')
    });
    return res;
  } catch (e) {
    const lang = await getLang().catch(() => 'zh');
    const msg = String(e?.message || e);
    await updatePrompt(localPromptId, {
      aiPending: false,
      aiErrorCode: 'NETWORK_ERROR',
      aiError: msg.includes('Network') || msg.includes('Failed to fetch') ? t(lang, 'networkPending') : t(lang, 'syncFailed', { code: msg }),
      aiQuotaExceeded: false,
      syncState: 'pending'
    });
    return { ok: false, status: 0, data: { error: 'NETWORK_ERROR', message: String(e?.message || e) } };
  }
}
