import { authFetch } from './auth.js';
import { apiRequest } from './api.js';
import { getAuthState, getInstallId, getPrompts, setLocalPromptLimit } from './storage.js';

async function fetchQuotaBySession(session, installId) {
  if (session?.accessToken) {
    const authRes = await authFetch('/api/quota', { method: 'GET' });
    if (authRes.ok) return authRes;
    if (authRes.status !== 401) return authRes;
  }
  if (!installId) return { ok: false, status: 401, data: { error: 'UNAUTHORIZED' } };
  return apiRequest(`/api/quota?install_id=${encodeURIComponent(installId)}`, { method: 'GET' });
}

async function reconcileAnonymousQuota(session, installId, quotaRes) {
  if (session?.accessToken || !installId || !quotaRes?.ok) return quotaRes;
  const data = quotaRes.data || {};
  if (data.plan_status !== 'anonymous') return quotaRes;
  const local = await getPrompts().catch(() => []);
  const localIds = local.map((p) => String(p?.id || '').trim()).filter(Boolean);
  if (Number(data.used || 0) <= localIds.length) return quotaRes;
  const reconcileRes = await apiRequest('/api/prompts/reconcile', {
    method: 'POST',
    body: { install_id: installId, local_prompt_ids: localIds }
  });
  if (!reconcileRes.ok) return quotaRes;
  return fetchQuotaBySession(session, installId);
}

export async function syncPromptLimit() {
  const [session, installId] = await Promise.all([
    getAuthState().catch(() => null),
    getInstallId().catch(() => '')
  ]);
  let res = await fetchQuotaBySession(session, installId);
  res = await reconcileAnonymousQuota(session, installId, res);
  if (res.ok) {
    await setLocalPromptLimit(res.data?.limit);
  }
  return res;
}
