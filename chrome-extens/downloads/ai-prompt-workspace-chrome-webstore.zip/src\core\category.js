export const CanonicalCategories = [
  '工作效率',
  '构思创意',
  '图像提示词',
  '视频提示词',
  '写作润色',
  '对话模拟',
  '开发技术',
  '其他'
];

function hasAny(text, keys) {
  for (const k of keys) {
    if (text.includes(k)) return true;
  }
  return false;
}

export function mapCategory(content, tags = []) {
  const t = (content || '').toLowerCase();
  const tagText = (Array.isArray(tags) ? tags.join(' ') : '').toLowerCase();
  const text = `${t} ${tagText}`;
  if (hasAny(text, ['midjourney', 'stable diffusion', 'sd', 'flux', 'mj', '图片', '图像', '插画', '海报', '摄影', 'cg', '3d', '建模', '渲染', '手办', 'pvc', 'pixar', '迪士尼', '光影', '材质'])) return '图像提示词';
  if (hasAny(text, ['视频', '短视频', '分镜', '运镜', '镜头', '旁白', '脚本', '口播', 'runway', 'sora', '剪辑', '动画视频'])) return '视频提示词';
  if (hasAny(text, ['会议纪要', '纪要', '会议记录', '摘要', '长文摘要', 'ppt', 'ppt大纲', '方案', '需求分析', '复盘'])) return '工作效率';
  if (hasAny(text, ['头脑风暴', '点子', '点子生成', '命名', '角度', '创意', 'slogan', '灵感', '发散'])) return '构思创意';
  if (hasAny(text, ['邮件', '报告', '文案', '总结', '润色', '改写', '风格', '措辞', '口吻'])) return '写作润色';
  if (hasAny(text, ['模拟面试', '面试', '客户沟通', '沟通', '辩论', '演练', '角色扮演', '对话', '话术'])) return '对话模拟';
  if (hasAny(text, ['代码', 'bug', '重构', '接口', 'api', '脚手架', '单元测试', 'python', 'sql', '后端', '全栈', '产品经理', '代码规范'])) return '开发技术';
  return '其他';
}
