export function autoResize(textarea) {
  textarea.style.height = 'auto';
  textarea.style.height = `${Math.min(80, textarea.scrollHeight)}px`;
}

export function mountSearchBar(el, onChange, onEnter) {
  autoResize(el);
  let timer = null;
  const emit = () => {
    onChange?.(el.value || '');
  };
  el.addEventListener('input', () => {
    autoResize(el);
    if (timer) clearTimeout(timer);
    timer = setTimeout(emit, 150);
  });
  el.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      onEnter?.(el.value || '');
    }
  });
}
