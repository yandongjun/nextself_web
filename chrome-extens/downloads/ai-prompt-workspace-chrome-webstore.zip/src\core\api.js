import { getUIState, setUIState } from './storage.js';

const DEFAULT_BASE = 'https://api.nextself.top';

export async function getApiBase() {
  const state = await getUIState();
  const v = (state.apiBase || '').trim();
  if (v && v !== DEFAULT_BASE) {
    // 发布包固定使用正式 API，避免本地调试地址残留污染商店版行为。
    await setUIState({ apiBase: '' }).catch(() => {});
  }
  return DEFAULT_BASE;
}

export async function apiRequest(path, { method = 'GET', headers = {}, body } = {}) {
  const base = await getApiBase();
  const url = base.replace(/\/+$/, '') + path;
  const h = { ...headers };
  if (body !== undefined) h['Content-Type'] = 'application/json';
  try {
    const res = await fetch(url, {
      method,
      headers: h,
      body: body !== undefined ? JSON.stringify(body) : undefined
    });
    const text = await res.text();
    let data = null;
    try {
      data = text ? JSON.parse(text) : null;
    } catch {
      data = { raw: text };
    }
    return { ok: res.ok, status: res.status, data };
  } catch (e) {
    return {
      ok: false,
      status: 0,
      data: { error: 'NETWORK_ERROR', message: String(e?.message || e) }
    };
  }
}
