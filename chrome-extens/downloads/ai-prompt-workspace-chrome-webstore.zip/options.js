// 选项页（大页面管理中心）：仅能在扩展上下文打开（chrome-extension://）。
if (!(typeof chrome !== 'undefined' && chrome.storage && chrome.runtime)) {
  document.body.innerHTML = '<div style="padding:20px;font-family:system-ui">请通过扩展的“扩展程序选项”或 Popup 的“进入管理页”按钮打开此页面。直接用文件路径打开将无法访问扩展数据。</div>';
  throw new Error('Not running in extension context');
}
import { getPrompts, subscribe, setPrompts, migrateIfNeeded, getUIState, setUIState, getInstallId, getAuthState, addPrompt, updatePrompt, ensureTaxonomy, setTaxonomy, getSyncCursor, setSyncCursor, getLocalPromptLimit, setLocalPromptLimit, togglePromptInContextMenu } from './src/core/storage.js';
import { applyFilter, computeTagIndex } from './src/core/filter.js';
import { CanonicalCategories } from './src/core/category.js';
import { renderMarkdown } from './src/core/markdown.js';
import { apiRequest, getApiBase } from './src/core/api.js';
import { login, logout, register, authFetch } from './src/core/auth.js';
import { suggestTags } from './src/core/tagger.js';
import { mapCategory } from './src/core/category.js';
import { classifyPrompt } from './src/core/aiClassify.js';
import { sendEvent } from './src/core/telemetry.js';
import { categoryLabel, documentLang, getLang, setLang, t, tagLabel, tagSearchTerms, promptTitleLabel, promptTitleSearchTerms } from './src/core/i18n.js';
import { syncPromptLimit } from './src/core/quota.js';

const ui = { search:'', cat:'', tags:[], list:[], taxonomy:null, recentDays:0, createdRange:'', favoriteOnly:false, sort:'', theme:'', viewMarkdown:false, batch:false, selection:new Set() };
const searchEl = document.getElementById('search');
const pillEl = document.getElementById('pill');
const catBar = document.getElementById('category');
const catScroll = document.getElementById('cat-scroll');
const tagBar = document.getElementById('tags');
const tagScroll = document.getElementById('tag-scroll');
const listEl = document.getElementById('list');
const fType = document.getElementById('f-type');
const fStatus = document.getElementById('f-status');
const fCreated = document.getElementById('f-created');
const fSort = document.getElementById('f-sort');
const fReset = document.getElementById('f-reset');
const optNew = document.getElementById('opt-new');
const optImport = document.getElementById('opt-import');
const optExport = document.getElementById('opt-export');
const optBatch = document.getElementById('opt-batch');
const optTagMgr = document.getElementById('opt-tagmgr');
const optSettings = document.getElementById('opt-settings');
const optTheme = document.getElementById('opt-theme');
const optLang = document.getElementById('opt-lang');
const optAccount = document.getElementById('opt-account');
const optBack = document.getElementById('opt-back');
const overlay = document.getElementById('overlay');
const batchBar = document.getElementById('batchbar');
const batchDel = document.getElementById('batch-del');
const batchTag = document.getElementById('batch-tag');
const batchCount = document.getElementById('batch-count');
const viewMarkdownEl = document.getElementById('view-markdown');
const accountEl = document.getElementById('account');
const authEmailEl = document.getElementById('auth-email');
const authPassEl = document.getElementById('auth-pass');
const authFormRowEl = document.getElementById('auth-form-row');
const authLoginEl = document.getElementById('auth-login');
const authRegisterEl = document.getElementById('auth-register');
const authLogoutEl = document.getElementById('auth-logout');
const authStatusEl = document.getElementById('auth-status');
const quotaEl = document.getElementById('quota');
const planSummaryEl = document.getElementById('plan-summary');
const planHintEl = document.getElementById('plan-hint');
const planUpgradeEl = document.getElementById('plan-upgrade');
const planManageEl = document.getElementById('plan-manage');
let authStatusTimer = null;
let lastListIds = new Set();
let hiddenNewCount = 0;
let focusId = '';
let lang = 'zh';
let billingState = null;
const BILLING_SITE = 'https://extension.nextself.top';
let pendingUpgradeFlow = false;
let upgradeFlowBusy = false;

function tt(key, vars) {
  return t(lang, key, vars);
}

function labelCategory(value) {
  return categoryLabel(lang, value);
}

function labelTag(value, dynamicEn = '') {
  return tagLabel(lang, value, dynamicEn);
}

function getTagAliases(value, dynamicEn = '') {
  return tagSearchTerms(value, dynamicEn);
}

function labelPromptTitle(item) {
  const base = String(item?.title || '').trim() || (item?.content || '').split(/\r?\n/)[0]?.trim() || tt('unnamedPrompt');
  return promptTitleLabel(lang, base, item?.titleEn || '');
}

function getTitleAliases(value, dynamicEn = '') {
  return promptTitleSearchTerms(value, dynamicEn);
}

async function buildUpgradeCheckoutUrl(billingToken) {
  const apiBase = await getApiBase().catch(() => 'https://api.nextself.top');
  const base = String(apiBase || 'https://api.nextself.top').trim().replace(/\/+$/, '');
  return `${BILLING_SITE}/pricing.html?api_base=${encodeURIComponent(base)}&billing_token=${encodeURIComponent(billingToken)}`;
}

function openBillingPage(url) {
  if (chrome?.tabs?.create) {
    chrome.tabs.create({ url });
    return;
  }
  window.open(url, '_blank');
}

function hasSignedInSession(session) {
  return !!(session?.accessToken || session?.refreshToken);
}

async function getUpgradeContext() {
  const session = await getAuthState();
  const list = await getPrompts();
  const hasLocalContent = list.some((item) => String(item?.content || '').trim());
  return { session, hasLocalContent };
}

function openAccountPanelForUpgrade(hasLocalContent) {
  pendingUpgradeFlow = true;
  accountEl.hidden = false;
  setAuthStatus(tt(hasLocalContent ? 'upgradeNeedLoginLocal' : 'upgradeNeedLoginNew'), 'error');
  if (authFormRowEl) authFormRowEl.hidden = false;
  authLogoutEl.hidden = true;
  authLoginEl.hidden = false;
  authRegisterEl.hidden = false;
  if (authEmailEl && typeof authEmailEl.focus === 'function') authEmailEl.focus();
}

async function claimAnonymousPromptsForCurrentUser() {
  const installId = await getInstallId();
  return authFetch('/api/prompts/claim-anonymous', {
    method: 'POST',
    body: { install_id: installId }
  });
}

async function syncPendingLocalPrompts(limit = 10) {
  const list = await getPrompts();
  const targets = list
    .filter((item) => !item?.serverPromptId && !item?.aiQuotaExceeded && String(item?.content || '').trim())
    .slice(0, limit);
  for (const item of targets) {
    await classifyPrompt(item.id, item.content || '').catch(() => {});
  }
  return targets.length;
}

async function createBoundBillingSession() {
  const installId = await getInstallId();
  return authFetch('/api/billing/session', {
    method: 'POST',
    body: { install_id: installId }
  });
}

async function continueUpgradeFlow() {
  if (upgradeFlowBusy) return;
  upgradeFlowBusy = true;
  pendingUpgradeFlow = false;
  planUpgradeEl.disabled = true;
  try {
    await refreshAccountUI();
    setAuthStatus(tt('upgradeClaimingAnonymous'), '');
    await claimAnonymousPromptsForCurrentUser().catch(() => null);
    await pullCloudPrompts().catch(() => {});
    setAuthStatus(tt('upgradeSyncingLocalPrompts'), '');
    await syncPendingLocalPrompts(10);
    setAuthStatus(tt('upgradePreparingBilling'), '');
    const res = await createBoundBillingSession();
    if (!res?.ok) {
      const message = res?.data?.message || res?.data?.error || res?.status || 'unknown';
      if (res?.status === 401) {
        const ctx = await getUpgradeContext();
        openAccountPanelForUpgrade(ctx.hasLocalContent);
        return;
      }
      setAuthStatus(tt('upgradeSessionFailed', { message }), 'error');
      return;
    }
    const billingToken = String(res?.data?.billing_token || '').trim();
    const email = String(res?.data?.user?.email || '').trim();
    if (!billingToken) {
      setAuthStatus(tt('upgradeSessionFailed', { message: 'missing billing token' }), 'error');
      return;
    }
    setAuthStatus(tt('upgradeOpenCheckout', { email: email || 'unknown' }), 'ok');
    openBillingPage(await buildUpgradeCheckoutUrl(billingToken));
    await refreshBillingState().catch(() => null);
  } finally {
    planUpgradeEl.disabled = false;
    upgradeFlowBusy = false;
  }
}

function needsAiRepair(item) {
  const title = String(item?.title || '').trim();
  const content = String(item?.content || '').trim();
  if (!content || item?.aiQuotaExceeded || item?.aiPending) return false;
  if (!title) return true;
  if (title.length >= 12 && content.startsWith(title)) return true;
  return /请严格遵守|处理规则|直接输出|不要输出|你是一位|请你|i want you to|please/i.test(title);
}

async function deletePromptFromServer(item) {
  const promptId = Number(item?.serverPromptId || 0);
  if (!promptId) return { ok: true, skipped: true };
  const installId = await getInstallId();
  const auth = await getAuthState();
  const body = { install_id: installId };
  const res = auth?.accessToken
    ? await authFetch(`/api/prompts/${promptId}`, { method: 'DELETE', body })
    : await apiRequest(`/api/prompts/${promptId}`, { method: 'DELETE', body });
  if (res.ok) return res;
  const code = res?.data?.error || String(res?.status || 'DELETE_FAILED');
  throw new Error(tt('syncFailed', { code }));
}

function applyStaticTexts() {
  document.documentElement.lang = documentLang(lang);
  document.title = tt('optionsTitle');
  if (optLang) optLang.textContent = '中文 / EN';
  optNew.textContent = tt('newPrompt');
  optImport.textContent = tt('import');
  optExport.textContent = tt('export');
  optBatch.textContent = tt('batchAction');
  optTagMgr.textContent = tt('tagManager');
  optAccount.textContent = tt('account');
  optBack.textContent = tt('backToPopup');
  authEmailEl.previousElementSibling.textContent = tt('email');
  authPassEl.previousElementSibling.textContent = tt('password');
  authLoginEl.textContent = tt('login');
  authRegisterEl.textContent = tt('register');
  authLogoutEl.textContent = tt('logout');
  planUpgradeEl.textContent = tt('upgradePlan');
  planManageEl.textContent = tt('managePlan');
  searchEl.placeholder = tt('searchFullPlaceholder');
  fStatus.options[0].text = tt('usageStatus');
  fStatus.options[1].text = tt('recent7Days');
  fStatus.options[2].text = tt('recent30Days');
  fStatus.options[3].text = tt('favorite');
  fCreated.options[0].text = tt('createdAt');
  fCreated.options[1].text = tt('today');
  fCreated.options[2].text = tt('thisWeek');
  fCreated.options[3].text = tt('thisMonth');
  fCreated.options[4].text = tt('thisYear');
  fSort.options[0].text = tt('sortRule');
  fSort.options[1].text = tt('recentUse');
  fSort.options[2].text = tt('createdAt');
  fSort.options[3].text = tt('usageFrequency');
  viewMarkdownEl.nextElementSibling.textContent = 'Markdown';
  fReset.textContent = tt('reset');
  const catAll = catBar.querySelector('.cat-all');
  if (catAll) catAll.textContent = tt('allCategories');
  const tagAll = tagBar.querySelector('.tag.all');
  if (tagAll) tagAll.textContent = tt('clearTags');
  batchDel.textContent = tt('deleteSelected');
  batchTag.textContent = tt('addTagToSelected');
  syncTaxonomyAccess();
}

function clearAllFilters() {
  ui.search = '';
  searchEl.value = '';
  ui.cat = '';
  fType.value = '';
  ui.tags = [];
  syncTags();
  ui.recentDays = 0;
  ui.favoriteOnly = false;
  fStatus.value = '';
  ui.createdRange = '';
  fCreated.value = '';
  ui.sort = '';
  fSort.value = '';
}

function getCurrentExtra() {
  return {
    recentDays: ui.recentDays,
    createdRange: ui.createdRange,
    favoriteOnly: ui.favoriteOnly,
    sort: ui.sort,
    tagAliases: getTagAliases,
    titleAliases: getTitleAliases
  };
}

function updateHiddenNewCount(nextList, addedIds) {
  const ids = Array.isArray(addedIds) ? addedIds.filter(Boolean) : [];
  if (!ids.length) {
    hiddenNewCount = 0;
    return;
  }
  const filtered = applyFilter(nextList, ui.cat, ui.tags, ui.search, getCurrentExtra());
  const visible = new Set(filtered.map((p) => p.id));
  hiddenNewCount = ids.filter((id) => !visible.has(id)).length;
}

function setAuthStatus(text, kind) {
  if (authStatusTimer) clearTimeout(authStatusTimer);
  authStatusTimer = null;
  authStatusEl.textContent = text || '';
  authStatusEl.classList.toggle('error', kind === 'error');
  authStatusEl.classList.toggle('ok', kind === 'ok');
}

function updateBatchUI() {
  // 批量模式 UI：按钮在“未选中任何条目”时置灰，同时展示已选数量。
  const n = ui.selection.size;
  batchDel.disabled = !n;
  batchTag.disabled = !n;
  batchCount.textContent = ui.batch ? tt('selectedCount', { count: n }) : '';
}

function renderList() {
  // 列表渲染：根据筛选条件派生 filtered，并将 UI 状态写入 uiState（供 Popup/Options 互通）。
  const filtered = applyFilter(ui.list, ui.cat, ui.tags, ui.search, getCurrentExtra());
  listEl.innerHTML = '';
  if (!filtered.length && ui.list.length) {
    const box = document.createElement('div');
    box.style.padding = '12px';
    box.style.border = '1px solid var(--border)';
    box.style.borderRadius = '12px';
    box.style.color = 'var(--muted)';
    box.style.display = 'grid';
    box.style.gap = '10px';
    const title = document.createElement('div');
    title.textContent = tt('noResults');
    const btn = document.createElement('button');
    btn.className = 'btn';
    btn.textContent = tt('clearFilters');
    btn.onclick = () => {
      clearAllFilters();
      renderCats();
      renderTags();
      renderList();
    };
    box.append(title, btn);
    listEl.append(box);
  }
  for (const it of filtered) {
    const card = document.createElement('div');
    card.className = 'item';
    card.dataset.id = it.id || '';
    if (focusId && it.id === focusId) card.classList.add('focus');
    if (ui.batch) {
      const ck = document.createElement('input');
      ck.type = 'checkbox';
      ck.checked = ui.selection.has(it.id);
      ck.onchange = () => {
        if (ck.checked) ui.selection.add(it.id);
        else ui.selection.delete(it.id);
        updateBatchUI();
      };
      card.append(ck);
    }
    const title = document.createElement('div');
    title.className = 'title';
    title.textContent = labelPromptTitle(it);
    const content = document.createElement('div');
    content.className = 'content collapsed';
    content.title = tt('clickToToggle');
    if (ui.viewMarkdown) {
      content.classList.add('md');
      renderMarkdown(it.content || '', content);
    } else {
      content.textContent = it.content;
    }
    content.onclick = () => content.classList.toggle('collapsed');
    if (it.translationZh) {
      const tr = document.createElement('div');
      tr.className = 'translation';
      tr.textContent = it.translationZh;
      card.append(title, content, tr);
    } else {
      card.append(title, content);
    }
    const meta = document.createElement('div');
    meta.className = 'meta';
    const tags = Array.isArray(it.tags) ? it.tags : [];
    const tagsEn = Array.isArray(it.tagsEn) ? it.tagsEn : [];
    for (let i = 0; i < tags.length; i += 1) {
      const tag = tags[i];
      const b = document.createElement('span');
      b.className = 'badge';
      b.textContent = labelTag(tag, tagsEn[i] || '');
      meta.append(b);
    }
    if (it.syncState === 'syncing') {
      const b = document.createElement('span');
      b.className = 'badge';
      b.textContent = tt('syncing');
      meta.append(b);
    }
    if (it.syncState === 'pending' && !it.aiQuotaExceeded) {
      const b = document.createElement('span');
      b.className = 'badge';
      b.textContent = tt('pendingSync');
      meta.append(b);
    }
    if (it.syncState === 'blocked' && !it.aiQuotaExceeded) {
      const b = document.createElement('span');
      b.className = 'badge';
      b.textContent = tt('blocked');
      if (it.aiError) b.title = String(it.aiError);
      meta.append(b);
    }
    if (it.aiPending) {
      const b = document.createElement('span');
      b.className = 'badge';
      b.textContent = tt('aiProcessing');
      meta.append(b);
    }
    if (it.aiQuotaExceeded) {
      const b = document.createElement('span');
      b.className = 'badge';
      b.textContent = tt('aiQuotaExceeded');
      meta.append(b);
    }
    const isNetwork = it.aiError && (String(it.aiError).toLowerCase().includes('network') || String(it.aiError).includes('网络'));
    if (it.aiError && !it.aiQuotaExceeded && !(it.syncState === 'pending' && isNetwork)) {
      const b = document.createElement('span');
      b.className = 'badge';
      b.textContent = tt('aiFailed');
      b.title = String(it.aiError);
      meta.append(b);
    }
    if (it.showInContextMenu) {
      const b = document.createElement('span');
      b.className = 'badge';
      b.textContent = tt('contextMenuPinned');
      meta.append(b);
    }
    const pinBtn = document.createElement('button');
    pinBtn.className = 'mini-btn';
    pinBtn.textContent = it.showInContextMenu ? tt('unpinFromContextMenu') : tt('pinToContextMenu');
    pinBtn.onclick = async () => {
      const res = await togglePromptInContextMenu(it.id, !it.showInContextMenu);
      ui.list = Array.isArray(res?.list) ? res.list : await getPrompts();
      const msg = it.showInContextMenu ? tt('contextMenuUnpinned') : tt('contextMenuPinned');
      setAuthStatus(res?.removedId ? `${msg} · ${tt('contextMenuOverflowRemoved')}` : msg, 'ok');
      renderCats();
      renderTags();
      renderList();
    };
    meta.append(pinBtn);
    const editBtn = document.createElement('button');
    editBtn.className = 'mini-btn';
    editBtn.textContent = tt('edit');
    editBtn.onclick = () => openEditPrompt(it);
    meta.append(editBtn);
    const delBtn = document.createElement('button');
    delBtn.className = 'mini-btn danger';
    delBtn.textContent = tt('delete');
    delBtn.onclick = async () => {
      if (!confirm(tt('deletePromptConfirm'))) return;
      try {
        await deletePromptFromServer(it);
      } catch (e) {
        setAuthStatus(String(e?.message || e), 'error');
        return;
      }
      const list = await getPrompts();
      const updated = list.filter((p) => p.id !== it.id);
      await setPrompts(updated);
      ui.selection.delete(it.id);
      sendEvent('prompt_delete', { count: 1, local_prompt_id: it.id, source: 'card' }).catch(() => {});
      ui.list = updated;
      renderCats();
      renderTags();
      renderList();
    };
    meta.append(delBtn);
    card.append(meta);
    listEl.append(card);
  }
  if (focusId) {
    const target = listEl.querySelector(`[data-id="${focusId}"]`);
    if (target && typeof target.scrollIntoView === 'function') {
      target.scrollIntoView({ block: 'center' });
      setTimeout(() => {
        try { target.classList.remove('focus'); } catch {}
      }, 1500);
      focusId = '';
      try {
        const params = new URLSearchParams(location.search);
        params.delete('focus');
        const qs = params.toString();
        history.replaceState(null, '', `${location.pathname}${qs ? `?${qs}` : ''}`);
      } catch {}
    }
  }
  updatePill(filtered.length);
  setUIState({ search: ui.search, cat: ui.cat, tags: ui.tags, theme: ui.theme, viewMarkdown: ui.viewMarkdown });
  updateBatchUI();
}

function updatePill(resultCount = 0) {
  const tagText = ui.tags.map((v) => labelTag(v)).join(',');
  const stateParts = [];
  if (ui.cat) stateParts.push(labelCategory(ui.cat));
  if (tagText) stateParts.push(tagText);
  if (ui.search) stateParts.push(ui.search);
  const stateText = stateParts.length ? ` | ${stateParts.join(' ')}` : '';
  const hiddenText = hiddenNewCount ? tt('hiddenSummary', { count: hiddenNewCount }) : '';
  pillEl.textContent = tt('resultSummary', {
    resultCount,
    totalCount: ui.list.length,
    stateText,
    hiddenText
  });
  if (hiddenNewCount) {
    pillEl.style.cursor = 'pointer';
    pillEl.onclick = () => {
      hiddenNewCount = 0;
      clearAllFilters();
      renderCats();
      renderTags();
      renderList();
    };
  } else {
    pillEl.style.cursor = '';
    pillEl.onclick = null;
  }
}

function renderCats() {
  // 固定一级分类栏（单选）：切换分类会清空标签多选，避免交叉条件造成误解。
  catScroll.innerHTML = '';
  const cats = Array.isArray(ui.taxonomy?.categories) ? ui.taxonomy.categories.map((x) => x.name).filter(Boolean) : CanonicalCategories;
  const extra = { recentDays: ui.recentDays, createdRange: ui.createdRange, favoriteOnly: ui.favoriteOnly, tagAliases: getTagAliases, titleAliases: getTitleAliases };
  const totalAll = applyFilter(ui.list, '', [], ui.search, extra).length;
  for (const c of cats) {
    const count = applyFilter(ui.list, c, [], ui.search, extra).length;
    const btn = document.createElement('button');
    btn.className = 'cat';
    btn.textContent = `${labelCategory(c)} (${count})`;
    btn.dataset.cat = c;
    if (c === ui.cat) btn.classList.add('active');
    btn.onclick = () => {
      if (ui.cat === c) ui.cat = '';
      else ui.cat = c;
      ui.tags = [];
      renderCats();
      renderTags();
      renderList();
    };
    catScroll.append(btn);
  }
  syncCats(totalAll);
}

function syncCats(totalAll = null) {
  const allBtn = catBar.querySelector('.cat-all');
  if (typeof totalAll === 'number') allBtn.textContent = `${tt('allCategories')} (${totalAll})`;
  else allBtn.textContent = tt('allCategories');
  if (!ui.cat) allBtn.classList.add('active'); else allBtn.classList.remove('active');
}

catBar.querySelector('.cat-all').onclick = () => {
  ui.cat = '';
  ui.tags = [];
  renderCats();
  renderTags();
  renderList();
};

function renderTags() {
  // 标签栏（多选 OR）：仅从“当前分类下的数据”派生标签频次，保证标签相关性。
  const base = applyFilter(ui.list, ui.cat, [], ui.search, { recentDays: ui.recentDays, createdRange: ui.createdRange, favoriteOnly: ui.favoriteOnly, tagAliases: getTagAliases, titleAliases: getTitleAliases });
  const idx = computeTagIndex(base);
  const arr = Array.from(idx.entries()).sort((a,b)=>b[1]-a[1]);
  tagScroll.innerHTML = '';
  const preferred = [];
  if (ui.cat && Array.isArray(ui.taxonomy?.categories)) {
    const catObj = ui.taxonomy.categories.find((c)=>c.name===ui.cat);
    if (catObj && Array.isArray(catObj.children)) preferred.push(...catObj.children.filter(Boolean));
  }
  const hideZero = !!((ui.search || '').trim() || ui.favoriteOnly || ui.recentDays || ui.createdRange);
  const seen = new Set();
  for (const tag of preferred) {
    const count = idx.get(tag) || 0;
    if (hideZero && !count) continue;
    const btn = document.createElement('button');
    btn.className = 'tag';
    const display = labelTag(tag);
    btn.textContent = count ? `${display} (${count})` : display;
    btn.dataset.tag = tag;
    if (ui.tags.includes(tag)) btn.classList.add('active');
    btn.onclick = () => {
      if (ui.tags.includes(tag)) ui.tags = ui.tags.filter((x)=>x!==tag);
      else ui.tags = [...ui.tags, tag];
      btn.classList.toggle('active', ui.tags.includes(tag));
      renderList();
      syncTags();
    };
    tagScroll.append(btn);
    seen.add(tag);
  }
  for (const [tag,count] of arr) {
    if (seen.has(tag)) continue;
    const btn = document.createElement('button');
    btn.className = 'tag';
    btn.textContent = `${labelTag(tag)} (${count})`;
    btn.dataset.tag = tag;
    if (ui.tags.includes(tag)) btn.classList.add('active');
    btn.onclick = () => {
      if (ui.tags.includes(tag)) ui.tags = ui.tags.filter((x)=>x!==tag);
      else ui.tags = [...ui.tags, tag];
      btn.classList.toggle('active', ui.tags.includes(tag));
      renderList();
      syncTags();
    };
    tagScroll.append(btn);
  }
  syncTags();
}

function syncTags() {
  const allBtn = tagBar.querySelector('.tag.all');
  if (!ui.tags.length) allBtn.classList.add('active'); else allBtn.classList.remove('active');
}
tagBar.querySelector('.tag.all').onclick = () => {
  ui.tags = [];
  renderTags();
  renderList();
};

function mountSearch() {
  // 搜索框：输入防抖，避免海量列表频繁重绘。
  let timer = null;
  const emit = () => { renderCats(); renderTags(); renderList(); };
  searchEl.addEventListener('input', () => {
    searchEl.style.height = 'auto';
    searchEl.style.height = `${Math.min(120, searchEl.scrollHeight)}px`;
    ui.search = searchEl.value || '';
    if (timer) clearTimeout(timer);
    timer = setTimeout(emit, 150);
  });
}

(function mountFilters(){
  fType.onchange = () => { ui.cat = fType.value || ''; ui.tags = []; renderCats(); renderTags(); renderList(); };
  fStatus.onchange = () => {
    const v = fStatus.value;
    if (v === 'fav') { ui.favoriteOnly = true; ui.recentDays = 0; }
    else { ui.favoriteOnly = false; ui.recentDays = Number(v) || 0; }
    renderCats();
    renderTags();
    renderList();
  };
  fCreated.onchange = () => { ui.createdRange = fCreated.value || ''; renderCats(); renderTags(); renderList(); };
  fSort.onchange = () => { ui.sort = fSort.value || ''; renderList(); };
  fReset.onclick = () => {
    ui.search=''; searchEl.value='';
    ui.cat=''; fType.value='';
    ui.tags=[]; syncTags();
    ui.recentDays=0; ui.favoriteOnly=false; fStatus.value='';
    ui.createdRange=''; fCreated.value='';
    ui.sort=''; fSort.value='';
    renderCats();
    renderTags();
    renderList();
  };
})();

(function mountViewMode(){
  viewMarkdownEl.onchange = () => {
    ui.viewMarkdown = !!viewMarkdownEl.checked;
    renderList();
  };
})();

function showEmptyHint() {
  if (ui.list.length) return;
  listEl.innerHTML = `<div style="padding:12px;color:#6b7280">${tt('emptyStorageHint')}</div>`;
  updatePill(0);
}

async function probeAndRecover() {
  // 诊断/自愈：当 options 读不到 prompts 时，探测 local/sync 的数据量并输出给用户。
  const readArea = (area) => new Promise((resolve) => {
    try {
      chrome.storage[area].get(['prompts'], (res) => {
        const err = chrome.runtime?.lastError?.message || '';
        const list = Array.isArray(res?.prompts) ? res.prompts : [];
        resolve({ area, list, err });
      });
    } catch (e) {
      resolve({ area, list: [], err: String(e?.message || e) });
    }
  });
  const local = await readArea('local');
  const sync = await readArea('sync');
  if (!ui.list.length && sync.list.length) {
    await setPrompts(sync.list);
    ui.list = sync.list;
    renderCats();
    renderTags();
    renderList();
    return;
  }
  if (!ui.list.length) {
    listEl.innerHTML =
      `<div style="padding:12px;color:#6b7280;display:grid;gap:8px">
        <div>${tt('emptyStorageLine1')}</div>
        <div>${tt('emptyStorageLine2', { id: chrome.runtime?.id || '-' })}</div>
        <div>${tt('emptyStorageLine3', { count: local.list.length, error: local.err ? ` (${local.err})` : '' })}</div>
        <div>${tt('emptyStorageLine4', { count: sync.list.length, error: sync.err ? ` (${sync.err})` : '' })}</div>
        <div>${tt('emptyStorageLine5')}</div>
      </div>`;
  }
  updatePill(0);
}

function openOverlay(node) {
  // 简易 Modal：点击遮罩或按 ESC 关闭，并禁用背景滚动。
  overlay.innerHTML = '';
  overlay.append(node);
  overlay.classList.add('show');
  document.body.classList.add('modal-open');
  overlay.onclick = (e)=>{ if (e.target===overlay) closeOverlay(); };
  window.addEventListener('keydown', onOverlayKeyDown);
}
function closeOverlay() {
  overlay.classList.remove('show');
  document.body.classList.remove('modal-open');
  overlay.innerHTML = '';
  window.removeEventListener('keydown', onOverlayKeyDown);
}

function onOverlayKeyDown(e) {
  if (e.key === 'Escape') closeOverlay();
}

function applyTheme(theme) {
  // 主题切换：使用 CSS 变量统一覆盖，避免 dark 模式出现“某些区域仍是白底”的割裂感。
  ui.theme = theme === 'dark' ? 'dark' : 'light';
  document.body.classList.toggle('dark', ui.theme === 'dark');
}

async function refreshQuota() {
  const res = await syncPromptLimit().catch(() => null);
  if (res.ok) {
    quotaEl.textContent = tt('quotaFormat', { used: res.data.used, limit: res.data.limit });
    return res.data;
  }
  quotaEl.textContent = '';
  return null;
}

function planName(plan, status) {
  if (plan === 'pro') return tt('planPro');
  if (status === 'anonymous') return tt('planAnonymous');
  return tt('planFree');
}

function planStatusText(status) {
  if (status === 'active') return tt('planStatusActive');
  if (status === 'anonymous') return tt('planStatusAnonymous');
  if (status === 'expired') return tt('planStatusExpired');
  return tt('planStatusUnknown');
}

async function refreshBillingState() {
  const installId = await getInstallId();
  const session = await getAuthState();
  const res = session?.accessToken
    ? await authFetch('/api/billing/state', { method: 'GET' })
    : await apiRequest(`/api/billing/state?install_id=${encodeURIComponent(installId)}`, { method: 'GET' });
  if (!res.ok) {
    billingState = null;
    planSummaryEl.textContent = '';
    planHintEl.textContent = tt('billingUnavailable');
    planUpgradeEl.hidden = false;
    planManageEl.hidden = true;
    syncTaxonomyAccess();
    return null;
  }
  const data = res.data || {};
  billingState = data;
  await setLocalPromptLimit(data?.limit);
  const localLimit = await getLocalPromptLimit();
  planSummaryEl.textContent = tt('planSummary', {
    plan: planName(data.plan, data.plan_status),
    status: planStatusText(data.plan_status)
  });
  if (data.plan === 'pro') {
    planHintEl.textContent = data.plan_status === 'expired' ? tt('billingHintExpired') : tt('billingHintPro');
  } else if (data.plan_status === 'anonymous') {
    planHintEl.textContent = tt('billingHintAnonymous');
  } else {
    planHintEl.textContent = tt('billingHintFree', { limit: data.limit || localLimit });
  }
  planUpgradeEl.hidden = data.plan === 'pro';
  planManageEl.hidden = true;
  syncTaxonomyAccess();
  return data;
}

function canManageTaxonomy() {
  return billingState?.plan === 'pro' && billingState?.plan_status === 'active';
}

function syncTaxonomyAccess() {
  if (!optTagMgr) return;
  const allowed = canManageTaxonomy();
  optTagMgr.disabled = !allowed;
  optTagMgr.title = allowed ? '' : tt('taxonomyManagerProOnly');
}

async function mergeCloudBatch(items, tombstones) {
  const cloudItems = Array.isArray(items) ? items : [];
  const cloudTombs = Array.isArray(tombstones) ? tombstones : [];
  if (!cloudItems.length && !cloudTombs.length) return false;
  const list = await getPrompts();
  const byId = new Map();
  for (let i = 0; i < list.length; i += 1) byId.set(list[i]?.id, i);
  let changed = false;
  if (cloudTombs.length) {
    const toDelete = new Set(cloudTombs.map((t) => String(t?.client_id || '')).filter(Boolean));
    if (toDelete.size) {
      const filtered = list.filter((p) => !toDelete.has(String(p?.id || '')));
      if (filtered.length !== list.length) {
        changed = true;
        await setPrompts(filtered);
        return true;
      }
    }
  }
  const next = Array.isArray(list) ? [...list] : [];
  for (const it of cloudItems) {
    const id = String(it?.client_id || '');
    if (!id) continue;
    const idx = byId.has(id) ? byId.get(id) : -1;
    const tags = Array.isArray(it?.tags) ? it.tags.filter(Boolean) : [];
    const tagsEn = Array.isArray(it?.tags_en) ? it.tags_en.filter(Boolean) : [];
    const categories = Array.isArray(it?.categories) ? it.categories.filter(Boolean) : [];
    if (idx >= 0) {
      const cur = next[idx] || {};
      const patch = {};
      if (!cur.serverPromptId && it?.server_id) patch.serverPromptId = it.server_id;
      if (!cur.content && it?.content) patch.content = it.content;
      if (!cur.title && it?.title) patch.title = it.title;
      if (!cur.titleEn && it?.title_en) patch.titleEn = it.title_en;
      if (!cur.translationZh && it?.translation_zh) patch.translationZh = it.translation_zh;
      if ((!Array.isArray(cur.tags) || cur.tags.length === 0) && tags.length) patch.tags = tags;
      if ((!Array.isArray(cur.tagsEn) || cur.tagsEn.length === 0) && tagsEn.length) patch.tagsEn = tagsEn;
      if ((!Array.isArray(cur.categories) || cur.categories.length === 0) && categories.length) {
        patch.categories = categories;
        patch.category = categories[0] || cur.category || '其他';
      } else if (!cur.category && categories.length) {
        patch.category = categories[0] || '其他';
      }
      if (it?.favorite && !cur.favorite) patch.favorite = true;
      if (!cur.createdAt && it?.created_at) patch.createdAt = Number(it.created_at) * 1000;
      if (!cur.syncedAt && it?.updated_at) patch.syncedAt = Number(it.updated_at) * 1000;
      if ((!cur.syncState || cur.syncState === 'pending') && (cur.serverPromptId || patch.serverPromptId)) patch.syncState = 'synced';
      const keys = Object.keys(patch);
      if (keys.length) {
        next[idx] = { ...cur, ...patch };
        changed = true;
      }
    } else {
      const createdAt = Number(it?.created_at || 0) * 1000 || Date.now();
      const updatedAt = Number(it?.updated_at || it?.created_at || 0) * 1000 || createdAt;
      const obj = {
        id,
        serverPromptId: it?.server_id || 0,
        title: String(it?.title || ''),
        titleEn: String(it?.title_en || ''),
        translationZh: String(it?.translation_zh || ''),
        content: String(it?.content || ''),
        tags,
        tagsEn,
        category: categories[0] || '其他',
        categories: categories.length ? categories : [categories[0] || '其他'],
        favorite: !!it?.favorite,
        syncState: 'synced',
        syncAttemptCount: 0,
        lastSyncAttemptAt: 0,
        syncedAt: updatedAt,
        aiPending: false,
        aiError: '',
        aiQuotaExceeded: false,
        usageCount: Number(it?.usage_count || 0),
        lastUsedAt: it?.last_used_at ? Number(it.last_used_at) * 1000 : 0,
        showInContextMenu: false,
        contextMenuPinnedAt: 0,
        createdAt
      };
      next.unshift(obj);
      byId.set(id, 0);
      changed = true;
    }
  }
  if (changed) await setPrompts(next);
  return changed;
}

async function pullCloudPrompts() {
  const session = await getAuthState();
  const userId = session?.user?.id;
  if (!userId || !session?.accessToken) return { ok: false, status: 401, data: { error: 'UNAUTHORIZED' } };
  let cursor = await getSyncCursor(userId);
  let rounds = 0;
  while (rounds < 50) {
    rounds += 1;
    const res = await authFetch(`/api/sync/pull?cursor=${encodeURIComponent(cursor)}&limit=200`, { method: 'GET' });
    if (!res.ok) return res;
    const nextCursor = Number(res?.data?.next_cursor || cursor) || cursor;
    const changed = await mergeCloudBatch(res?.data?.items, res?.data?.tombstones);
    if (nextCursor > cursor) {
      cursor = nextCursor;
      await setSyncCursor(userId, cursor);
    }
    const hasMore = (Array.isArray(res?.data?.items) && res.data.items.length) || (Array.isArray(res?.data?.tombstones) && res.data.tombstones.length);
    if (!hasMore) break;
    if (!changed && nextCursor <= cursor) break;
  }
  return { ok: true };
}

async function refreshAccountUI() {
  const session = await getAuthState();
  const email = String(session?.user?.email || '').trim();
  const hasSession = hasSignedInSession(session);
  if (hasSession) {
    setAuthStatus(tt('loggedIn', { email: email || 'account' }), 'ok');
    if (authFormRowEl) authFormRowEl.hidden = true;
    authLogoutEl.hidden = false;
    authLoginEl.hidden = true;
    authRegisterEl.hidden = true;
  } else {
    setAuthStatus(tt('notLoggedIn'), '');
    if (authFormRowEl) authFormRowEl.hidden = false;
    authLogoutEl.hidden = true;
    authLoginEl.hidden = false;
    authRegisterEl.hidden = false;
  }
  await refreshQuota();
  await refreshBillingState();
}

function formatAuthError(action, res) {
  const err = res?.data?.error || '';
  if (err === 'INVALID_INPUT') return tt('authInvalidInput', { action });
  if (err === 'EMAIL_EXISTS') return tt('authEmailExists', { action });
  if (err === 'USER_NOT_FOUND') return tt('authUserNotFound', { action });
  if (err === 'INVALID_PASSWORD') return tt('authInvalidPassword', { action });
  if (res?.status === 401) return tt('authUnauthorized', { action });
  return tt('authUnknownError', { action, message: res?.data?.message || err || res?.status || 'unknown' });
}

(function mountTopbar(){
  if (optLang) {
    optLang.onclick = async () => {
      lang = await setLang(lang === 'zh' ? 'en' : 'zh');
      applyStaticTexts();
      hydrateTypeOptions();
      renderCats();
      renderTags();
      renderList();
      await refreshAccountUI();
    };
  }
  optTheme.onclick = () => {
    applyTheme(document.body.classList.contains('dark') ? 'light' : 'dark');
    setUIState({ theme: ui.theme });
  };
  optBack.onclick = () => { window.open(chrome.runtime.getURL('popup.html'), '_blank'); };
  optAccount.onclick = async () => {
    accountEl.hidden = !accountEl.hidden;
    if (!accountEl.hidden) await refreshAccountUI();
  };
  authLoginEl.onclick = async () => {
    const email = (authEmailEl.value || '').trim();
    const pass = (authPassEl.value || '').trim();
    if (!email || !pass) {
      setAuthStatus(tt('authInvalidInput', { action: tt('login') }), 'error');
      return;
    }
    authLoginEl.disabled = true;
    authRegisterEl.disabled = true;
    try {
      const res = await login(email, pass);
      if (!res.ok) {
        setAuthStatus(formatAuthError(tt('login'), res), 'error');
        return;
      }
      setAuthStatus(tt('loggedIn', { email: res.data.user.email }), 'ok');
      await refreshAccountUI();
      await pullCloudPrompts().catch(() => {});
      if (pendingUpgradeFlow) {
        await continueUpgradeFlow();
      }
    } finally {
      authLoginEl.disabled = false;
      authRegisterEl.disabled = false;
    }
  };
  authRegisterEl.onclick = async () => {
    const email = (authEmailEl.value || '').trim();
    const pass = (authPassEl.value || '').trim();
    if (!email || !pass) {
      setAuthStatus(tt('authInvalidInput', { action: tt('register') }), 'error');
      return;
    }
    authLoginEl.disabled = true;
    authRegisterEl.disabled = true;
    try {
      const res = await register(email, pass);
      if (!res.ok) {
        setAuthStatus(formatAuthError(tt('register'), res), 'error');
        return;
      }
      setAuthStatus(tt('loggedIn', { email: res.data.user.email }), 'ok');
      await refreshAccountUI();
      await pullCloudPrompts().catch(() => {});
      if (pendingUpgradeFlow) {
        await continueUpgradeFlow();
      }
    } finally {
      authLoginEl.disabled = false;
      authRegisterEl.disabled = false;
    }
  };
  authLogoutEl.onclick = async () => {
    pendingUpgradeFlow = false;
    await logout();
    await refreshAccountUI();
  };
  planUpgradeEl.onclick = async () => {
    const ctx = await getUpgradeContext();
    if (!hasSignedInSession(ctx.session)) {
      openAccountPanelForUpgrade(ctx.hasLocalContent);
      return;
    }
    await continueUpgradeFlow();
  };
  planManageEl.onclick = () => {
    alert(tt('billingComingSoon'));
  };
  const syncBatchBar = () => {
    batchBar.classList.toggle('show', ui.batch);
    updateBatchUI();
  };
  optBatch.onclick = () => {
    ui.batch = !ui.batch;
    ui.selection.clear();
    syncBatchBar();
    renderList();
  };
  syncBatchBar();
  batchDel.onclick = async () => {
    if (!ui.selection.size) return;
    const list = await getPrompts();
    const selected = list.filter((p) => ui.selection.has(p.id));
    try {
      for (const item of selected) {
        await deletePromptFromServer(item);
      }
    } catch (e) {
      setAuthStatus(String(e?.message || e), 'error');
      return;
    }
    const updated = list.filter((p)=> !ui.selection.has(p.id));
    await setPrompts(updated);
    sendEvent('prompt_delete', { count: ui.selection.size });
    ui.selection.clear();
    ui.list = updated;
    renderCats();
    renderTags();
    renderList();
  };
  batchTag.onclick = async () => {
    if (!ui.selection.size) return;
    const tg = prompt(tt('batchAddTagPrompt')) || '';
    if (!tg) return;
    const list = await getPrompts();
    const updated = list.map((p)=> ui.selection.has(p.id) ? { ...p, tags: Array.from(new Set([...(p.tags||[]), tg])) } : p );
    await setPrompts(updated);
    renderList();
  };
  optExport.onclick = async () => {
    const data = applyFilter(ui.list, ui.cat, ui.tags, ui.search, { recentDays: ui.recentDays, createdRange: ui.createdRange, favoriteOnly: ui.favoriteOnly, sort: ui.sort, tagAliases: getTagAliases, titleAliases: getTitleAliases });
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'prompts.json'; a.click();
    setTimeout(()=>URL.revokeObjectURL(url), 1000);
  };
  optImport.onclick = async () => {
    const input = document.createElement('input'); input.type='file'; input.accept='.json,.csv';
    input.onchange = async () => {
      const file = input.files?.[0]; if (!file) return;
      const text = await file.text();
      let arr = [];
      if (file.name.endsWith('.csv')) {
        const lines = text.split(/\r?\n/).filter(Boolean);
        for (const ln of lines) {
          const cols = ln.split(',');
          const content = cols[0] || '';
          const tags = (cols[1]||'').split('|').filter(Boolean);
          const category = cols[2] || '';
          arr.push({ id: crypto.randomUUID(), title:'', titleEn:'', translationZh:'', content, tags, tagsEn: [], category, categories: category ? [category] : [], syncState:'pending', syncAttemptCount:0, lastSyncAttemptAt:0, syncedAt:0, aiPending:false, usageCount:0, createdAt: Date.now() });
        }
      } else {
        try {
          const parsed = JSON.parse(text);
          arr = Array.isArray(parsed) ? parsed : (Array.isArray(parsed?.prompts) ? parsed.prompts : []);
        } catch { arr = []; }
      }
      const normalize = (t) => String(t || '').replace(/\r\n/g, '\n').trim();
      await syncPromptLimit().catch(() => null);
      const list = await getPrompts();
      const promptLimit = await getLocalPromptLimit();
      const seen = new Set(list.map((p) => normalize(p?.content)));
      const imported = [];
      let skipped = 0;
      for (const raw of (Array.isArray(arr) ? arr : [])) {
        if (imported.length + list.length >= promptLimit) break;
        const content = normalize(raw?.content);
        if (!content) continue;
        if (seen.has(content)) { skipped += 1; continue; }
        const tags = Array.isArray(raw?.tags) ? raw.tags.filter(Boolean) : [];
        const category = String(raw?.category || '').trim() || mapCategory(content, tags);
        const createdAt = Number(raw?.createdAt || 0) || Date.now();
        imported.push({
          id: crypto.randomUUID(),
          title: typeof raw?.title === 'string' ? raw.title : '',
          titleEn: typeof raw?.titleEn === 'string' ? raw.titleEn : (typeof raw?.title_en === 'string' ? raw.title_en : ''),
          translationZh: typeof raw?.translationZh === 'string' ? raw.translationZh : (typeof raw?.translation_zh === 'string' ? raw.translation_zh : ''),
          content,
          tags,
          tagsEn: Array.isArray(raw?.tagsEn) ? raw.tagsEn.filter(Boolean) : (Array.isArray(raw?.tags_en) ? raw.tags_en.filter(Boolean) : []),
          category,
          categories: Array.isArray(raw?.categories) && raw.categories.length ? raw.categories.filter(Boolean) : [category],
          favorite: !!raw?.favorite,
          showInContextMenu: !!raw?.showInContextMenu,
          contextMenuPinnedAt: Number(raw?.contextMenuPinnedAt || 0) || 0,
          serverPromptId: raw?.serverPromptId || raw?.server_prompt_id || '',
          syncState: (raw?.serverPromptId || raw?.server_prompt_id) ? 'synced' : 'pending',
          syncAttemptCount: 0,
          lastSyncAttemptAt: 0,
          syncedAt: 0,
          aiPending: false,
          aiError: '',
          aiQuotaExceeded: false,
          usageCount: Number(raw?.usageCount || 0) || 0,
          lastUsedAt: Number(raw?.lastUsedAt || 0) || 0,
          createdAt
        });
        seen.add(content);
      }
      await setPrompts([...imported, ...list]);
      ui.list = await getPrompts();
      renderCats();
      renderTags();
      renderList();
      if (imported.length || skipped) {
        const extra = { recentDays: ui.recentDays, createdRange: ui.createdRange, favoriteOnly: ui.favoriteOnly, sort: ui.sort, tagAliases: getTagAliases, titleAliases: getTitleAliases };
        const shown = applyFilter(ui.list, ui.cat, ui.tags, ui.search, extra).length;
        let msg = tt('importSummary', { imported: imported.length, skipped });
        if (list.length + imported.length >= promptLimit) {
          msg += tt('importLimitReached', { max: promptLimit });
        }
        msg += tt('importCurrentStats', { total: ui.list.length, shown });
        alert(msg);
      }
    };
    input.click();
  };
  optNew.onclick = async () => {
    const wrap = document.createElement('div');
    wrap.style.display='grid'; wrap.style.placeItems='center'; wrap.style.height='100%';
    const card = document.createElement('div');
    card.style.width='480px'; card.style.background='var(--surface)'; card.style.border='1px solid var(--border)'; card.style.padding='12px'; card.style.borderRadius='12px'; card.style.boxShadow='var(--shadow-md)';
    const ta = document.createElement('textarea'); ta.style.width='100%'; ta.style.minHeight='120px';
    const actions = document.createElement('div'); actions.style.display='flex'; actions.style.justifyContent='flex-end'; actions.style.gap='8px'; actions.style.marginTop='8px';
    const cancel = document.createElement('button'); cancel.textContent=tt('cancel'); cancel.className='btn';
    const ok = document.createElement('button'); ok.textContent=tt('submit'); ok.className='btn primary';
    actions.append(cancel, ok);
    card.append(ta, actions); wrap.append(card);
    openOverlay(wrap);
    cancel.onclick = closeOverlay;
    ok.onclick = async () => {
      try {
        const content = (ta.value||'').trim();
        if (!content) return closeOverlay();
        const tags = suggestTags(content);
        const category = (ui.cat || '').trim() || mapCategory(content, tags);
        const item = { id: crypto.randomUUID(), title:'', titleEn:'', translationZh:'', content, tags, tagsEn: [], category, categories:[category], syncState:'pending', syncAttemptCount:0, lastSyncAttemptAt:0, syncedAt:0, aiPending: false, usageCount:0, showInContextMenu:false, contextMenuPinnedAt:0, createdAt: Date.now() };
        await syncPromptLimit().catch(() => null);
        await addPrompt(item);
        ui.list = await getPrompts();
        const extra = { recentDays: ui.recentDays, createdRange: ui.createdRange, favoriteOnly: ui.favoriteOnly, sort: ui.sort, tagAliases: getTagAliases, titleAliases: getTitleAliases };
        const visible = applyFilter(ui.list, ui.cat, ui.tags, ui.search, extra).some((p) => p.id === item.id);
        if (!visible) {
          ui.search = '';
          searchEl.value = '';
          ui.tags = [];
          syncTags();
          ui.cat = '';
          fType.value = '';
          ui.recentDays = 0;
          ui.favoriteOnly = false;
          fStatus.value = '';
          ui.createdRange = '';
          fCreated.value = '';
        }
        renderCats();
        renderTags();
        renderList();
        classifyPrompt(item.id, item.content).catch(() => {});
        closeOverlay();
      } catch (e) {
        const code = String(e?.code || e?.message || e);
        const limit = Number(e?.limit || 0) || await getLocalPromptLimit();
        const message = code === 'LIMIT_EXCEEDED' ? tt('limitExceeded', { max: limit }) : String(e?.message || e);
        alert(tt('saveFailed', { message }));
      }
    };
  };
  optTagMgr.onclick = async () => {
    if (!canManageTaxonomy()) {
      setAuthStatus(tt('taxonomyManagerProOnly'), 'error');
      return;
    }
    ui.taxonomy = await ensureTaxonomy();
    const wrap = document.createElement('div');
    wrap.style.display='grid'; wrap.style.placeItems='center'; wrap.style.height='100%';
    const card = document.createElement('div');
    card.style.width='900px'; card.style.background='var(--surface)'; card.style.border='1px solid var(--border)'; card.style.padding='12px'; card.style.borderRadius='12px'; card.style.boxShadow='var(--shadow-md)';
    const title = document.createElement('div'); title.textContent=tt('tagCategoryManager');
    const main = document.createElement('div'); main.style.display='grid'; main.style.gridTemplateColumns='1fr 1fr'; main.style.gap='12px'; main.style.marginTop='10px';
    const left = document.createElement('div'); left.style.border='1px solid var(--border)'; left.style.borderRadius='12px'; left.style.padding='10px'; left.style.display='grid'; left.style.gap='10px';
    const right = document.createElement('div'); right.style.border='1px solid var(--border)'; right.style.borderRadius='12px'; right.style.padding='10px'; right.style.display='grid'; right.style.gap='10px';
    const catList = document.createElement('div'); catList.style.display='grid'; catList.style.gap='8px'; catList.style.maxHeight='420px'; catList.style.overflow='auto';
    const tagList = document.createElement('div'); tagList.style.display='grid'; tagList.style.gap='8px'; tagList.style.maxHeight='420px'; tagList.style.overflow='auto';
    const leftActions = document.createElement('div'); leftActions.style.display='flex'; leftActions.style.gap='8px';
    const addCatBtn = document.createElement('button'); addCatBtn.className='btn'; addCatBtn.textContent=tt('addPrimaryTag');
    leftActions.append(addCatBtn);
    const rightActions = document.createElement('div'); rightActions.style.display='flex'; rightActions.style.gap='8px'; rightActions.style.flexWrap='wrap';
    const addTagBtn = document.createElement('button'); addTagBtn.className='btn'; addTagBtn.textContent=tt('addSecondaryTag');
    rightActions.append(addTagBtn);
    left.append(leftActions, catList);
    right.append(rightActions, tagList);
    main.append(left, right);
    const footer = document.createElement('div'); footer.style.display='flex'; footer.style.justifyContent='flex-end'; footer.style.gap='8px'; footer.style.marginTop='10px';
    const closeBtn = document.createElement('button'); closeBtn.textContent=tt('close'); closeBtn.className='btn';
    card.append(title, main, footer); wrap.append(card);
    openOverlay(wrap);
    closeBtn.onclick = closeOverlay; footer.append(closeBtn);
    let selectedCat = ui.cat || (ui.taxonomy?.categories?.[0]?.name || '其他');
    const ensureOther = (taxonomy) => {
      const cats = Array.isArray(taxonomy?.categories) ? taxonomy.categories : [];
      if (!cats.some((c)=>c.name==='其他')) cats.push({ name:'其他', children:[] });
      taxonomy.categories = cats;
    };
    const commitTaxonomy = async (next) => {
      ensureOther(next);
      ui.taxonomy = next;
      await setTaxonomy(next);
      hydrateTypeOptions();
      renderCats();
      renderTags();
      renderList();
    };
    const rebuildCats = async () => {
      catList.innerHTML = '';
      const cats = Array.isArray(ui.taxonomy?.categories) ? ui.taxonomy.categories : [];
      for (const c of cats) {
        const row = document.createElement('div'); row.style.display='flex'; row.style.gap='8px'; row.style.alignItems='center';
        const name = document.createElement('button'); name.className='mini-btn'; name.textContent = labelCategory(c.name); name.style.flex='1';
        if (c.name === selectedCat) name.style.borderColor = 'var(--primary2)';
        name.onclick = () => { selectedCat = c.name; rebuildCats(); rebuildTags(); };
        const rename = document.createElement('button'); rename.className='btn'; rename.textContent=tt('rename');
        const del = document.createElement('button'); del.className='btn'; del.textContent=tt('delete');
        row.append(name, rename, del);
        catList.append(row);
        rename.onclick = async () => {
          const to = (prompt(tt('renamePrimaryPrompt'), c.name) || '').trim();
          if (!to || to === c.name) return;
          const next = JSON.parse(JSON.stringify(ui.taxonomy));
          const cc = next.categories.find((x)=>x.name===c.name);
          cc.name = to;
          if (selectedCat === c.name) selectedCat = to;
          if (ui.cat === c.name) ui.cat = to;
          const list = await getPrompts();
          const updated = list.map((p)=> p.category===c.name ? { ...p, category: to } : p);
          await setPrompts(updated);
          await commitTaxonomy(next);
          rebuildCats(); rebuildTags();
        };
        del.onclick = async () => {
          if (c.name === '其他') return;
          if (!confirm(tt('deletePrimaryConfirm', { name: c.name }))) return;
          const next = JSON.parse(JSON.stringify(ui.taxonomy));
          next.categories = next.categories.filter((x)=>x.name!==c.name);
          const list = await getPrompts();
          const updated = list.map((p)=> p.category===c.name ? { ...p, category: '其他' } : p);
          await setPrompts(updated);
          if (selectedCat === c.name) selectedCat = '其他';
          if (ui.cat === c.name) ui.cat = '其他';
          await commitTaxonomy(next);
          rebuildCats(); rebuildTags();
        };
      }
    };
    const rebuildTags = async () => {
      tagList.innerHTML = '';
      const cats = Array.isArray(ui.taxonomy?.categories) ? ui.taxonomy.categories : [];
      const catObj = cats.find((x)=>x.name===selectedCat) || cats.find((x)=>x.name==='其他');
      const children = Array.isArray(catObj?.children) ? catObj.children : [];
      const list = await getPrompts();
      const base = applyFilter(list, selectedCat, [], '');
      const idx = computeTagIndex(base);
      const merged = Array.from(new Set([...children, ...Array.from(idx.keys())]));
      merged.sort((a,b)=> (idx.get(b)||0) - (idx.get(a)||0));
      for (const tg of merged) {
        const row = document.createElement('div'); row.style.display='flex'; row.style.gap='8px'; row.style.alignItems='center';
        const name = document.createElement('span'); name.textContent = String(tg || '');
        name.style.flex='1';
        const rename = document.createElement('button'); rename.className='btn'; rename.textContent=tt('rename');
        const del = document.createElement('button'); del.className='btn'; del.textContent=tt('delete');
        row.append(name, rename, del);
        tagList.append(row);
        rename.onclick = async () => {
          const to = (prompt(tt('renameSecondaryPrompt'), tg) || '').trim();
          if (!to || to === tg) return;
          const next = JSON.parse(JSON.stringify(ui.taxonomy));
          const cc = next.categories.find((x)=>x.name===catObj.name);
          cc.children = (cc.children||[]).map((x)=> x===tg ? to : x);
          const updated = list.map((p)=>({ ...p, tags: (p.tags||[]).map((x)=> x===tg ? to : x) }));
          await setPrompts(updated);
          await commitTaxonomy(next);
          rebuildTags();
        };
        del.onclick = async () => {
          if (!confirm(tt('deleteSecondaryConfirm', { name: tg }))) return;
          const next = JSON.parse(JSON.stringify(ui.taxonomy));
          const cc = next.categories.find((x)=>x.name===catObj.name);
          cc.children = (cc.children||[]).filter((x)=>x!==tg);
          const updated = list.map((p)=>({ ...p, tags: (p.tags||[]).filter((x)=>x!==tg) }));
          await setPrompts(updated);
          await commitTaxonomy(next);
          rebuildTags();
        };
      }
    };
    addCatBtn.onclick = async () => {
      const name = (prompt(tt('addPrimaryPrompt')) || '').trim();
      if (!name) return;
      const next = JSON.parse(JSON.stringify(ui.taxonomy));
      ensureOther(next);
      if (!next.categories.some((c)=>c.name===name)) next.categories.push({ name, children: [] });
      await commitTaxonomy(next);
      selectedCat = name;
      rebuildCats(); rebuildTags();
    };
    addTagBtn.onclick = async () => {
      const tg = (prompt(tt('addSecondaryPrompt')) || '').trim();
      if (!tg) return;
      const next = JSON.parse(JSON.stringify(ui.taxonomy));
      const cc = next.categories.find((x)=>x.name===selectedCat) || next.categories.find((x)=>x.name==='其他');
      cc.children = Array.from(new Set([...(cc.children||[]), tg]));
      await commitTaxonomy(next);
      rebuildTags();
    };
    rebuildCats();
    rebuildTags();
  };
})();

(async function init(){
  try {
    const focusFromUrl = (new URLSearchParams(location.search).get('focus') || '').trim();
    lang = await getLang();
    applyStaticTexts();
    await migrateIfNeeded();
    ui.taxonomy = await ensureTaxonomy();
    hydrateTypeOptions();
    syncTaxonomyAccess();
    ui.list = await getPrompts();
    lastListIds = new Set(ui.list.map((p) => p?.id).filter(Boolean));
    const state = await getUIState();
    if (state) {
      ui.search = state.search || '';
      ui.cat = state.cat || '';
      ui.tags = Array.isArray(state.tags) ? state.tags : [];
      applyTheme(state.theme || 'light');
      ui.viewMarkdown = !!state.viewMarkdown;
      searchEl.value = ui.search;
      fType.value = ui.cat;
      viewMarkdownEl.checked = ui.viewMarkdown;
    }
    if (focusFromUrl) {
      hiddenNewCount = 0;
      focusId = focusFromUrl;
      clearAllFilters();
    }
    renderCats();
    renderTags();
    mountSearch();
    renderList();
    showEmptyHint();
    await refreshAccountUI().catch(() => null);
    await syncPromptLimit().catch(() => null);
    await refreshBillingState().catch(() => null);
    if (!ui.list.length) await probeAndRecover();
    if (!ui.list.length) {
      await pullCloudPrompts().catch(() => {});
      ui.list = await getPrompts();
      renderCats();
      renderTags();
      renderList();
    }
    const retryTargets = ui.list
      .filter((p) => (
        (!p.serverPromptId && !p.aiQuotaExceeded && (p.aiPending || p.aiError))
        || (p.serverPromptId && needsAiRepair(p))
      ))
      .slice(0, 10);
    for (const p of retryTargets) {
      classifyPrompt(p.id, p.content || '').catch(() => {});
    }
    subscribe((list2)=>{
      const next = Array.isArray(list2) ? list2 : [];
      const added = [];
      for (const p of next) {
        const id = p?.id;
        if (id && !lastListIds.has(id)) added.push(id);
      }
      lastListIds = new Set(next.map((p) => p?.id).filter(Boolean));
      updateHiddenNewCount(next, added);
      ui.list = list2;
      renderCats();
      renderTags();
      renderList();
    });
  } catch (e) {
    listEl.innerHTML = `<div style="padding:12px;color:#b91c1c">${tt('optionsInitFailed', { message: String(e?.message || e) })}</div>`;
  }
})();

function hydrateTypeOptions() {
  const cats = Array.isArray(ui.taxonomy?.categories) ? ui.taxonomy.categories.map((x) => x.name).filter(Boolean) : CanonicalCategories;
  const curr = fType.value || '';
  fType.innerHTML = '';
  const opt0 = document.createElement('option');
  opt0.value = '';
  opt0.textContent = tt('allTypes');
  fType.append(opt0);
  for (const c of cats) {
    const opt = document.createElement('option');
    opt.value = c;
    opt.textContent = labelCategory(c);
    fType.append(opt);
  }
  fType.value = curr;
}

function openEditPrompt(item) {
  const wrap = document.createElement('div');
  wrap.style.display='grid'; wrap.style.placeItems='center'; wrap.style.height='100%';
  const card = document.createElement('div');
  card.style.width='720px'; card.style.background='var(--surface)'; card.style.border='1px solid var(--border)'; card.style.padding='12px'; card.style.borderRadius='12px'; card.style.boxShadow='var(--shadow-md)'; card.style.display='grid'; card.style.gap='10px';
  const title = document.createElement('div');
  title.textContent = tt('editPromptTitle');
  const ta = document.createElement('textarea');
  ta.style.width='100%'; ta.style.minHeight='220px';
  ta.value = item.content || '';
  const titleInput = document.createElement('input');
  titleInput.className = 'input';
  titleInput.placeholder = tt('titlePlaceholder');
  titleInput.value = item.title || '';
  const row = document.createElement('div');
  row.style.display='flex'; row.style.gap='10px'; row.style.alignItems='center'; row.style.flexWrap='wrap';
  const catSel = document.createElement('select');
  const cats = Array.isArray(ui.taxonomy?.categories) ? ui.taxonomy.categories.map((x) => x.name).filter(Boolean) : CanonicalCategories;
  for (const c of [''].concat(cats)) {
    const opt = document.createElement('option');
    opt.value = c;
    opt.textContent = c ? labelCategory(c) : tt('selectPrimaryTag');
    catSel.append(opt);
  }
  catSel.value = item.category || '';
  const tagsInput = document.createElement('input');
  tagsInput.className = 'input';
  tagsInput.placeholder = tt('tagPlaceholder');
  tagsInput.style.flex = '1';
  tagsInput.value = Array.isArray(item.tags) ? item.tags.join(',') : '';
  const mdToggle = document.createElement('label');
  mdToggle.className = 'toggle';
  const mdCk = document.createElement('input'); mdCk.type='checkbox'; mdCk.checked = true;
  const mdText = document.createElement('span'); mdText.textContent = tt('preview');
  mdToggle.append(mdCk, mdText);
  row.append(catSel, tagsInput, mdToggle);
  const preview = document.createElement('div');
  preview.className = 'content md';
  preview.style.border = '1px solid var(--border)';
  preview.style.borderRadius = '12px';
  preview.style.padding = '10px 12px';
  preview.style.background = 'var(--surface)';
  const refreshPreview = () => {
    if (!mdCk.checked) {
      preview.textContent = ta.value || '';
      preview.classList.remove('md');
      return;
    }
    preview.classList.add('md');
    renderMarkdown(ta.value || '', preview);
  };
  mdCk.onchange = refreshPreview;
  ta.oninput = refreshPreview;
  refreshPreview();
  const actions = document.createElement('div');
  actions.style.display='flex'; actions.style.justifyContent='flex-end'; actions.style.gap='8px';
  const cancel = document.createElement('button'); cancel.className='btn'; cancel.textContent=tt('cancel');
  const save = document.createElement('button'); save.className='btn primary'; save.textContent=tt('save');
  actions.append(cancel, save);
  cancel.onclick = closeOverlay;
  save.onclick = async () => {
    const content = (ta.value || '').trim();
    const category = (catSel.value || '').trim() || '其他';
    const tags = (tagsInput.value || '').split(',').map((x)=>x.trim()).filter(Boolean);
    const t2 = (titleInput.value || '').trim();
    await updatePrompt(item.id, { title: t2, content, category, categories: [category], tags });
    renderCats();
    hydrateTypeOptions();
    renderTags();
    renderList();
    closeOverlay();
  };
  card.append(title, titleInput, row, ta, preview, actions);
  wrap.append(card);
  openOverlay(wrap);
}
