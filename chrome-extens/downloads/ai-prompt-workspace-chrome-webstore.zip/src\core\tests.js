import { applyFilter } from './filter.js';
import { suggestTags } from './tagger.js';
import { getPrompts, addPrompt } from './storage.js';
import { mapCategory } from './category.js';

export async function runTests() {
  const tags = suggestTags('Midjourney 二次元 高质量 光影 MJ');
  console.log('TAGGER', tags);
  const cat = mapCategory('测试提示词 MJ 二次元', ['MJ','二次元']);
  const demo = { id: crypto.randomUUID(), content: '测试提示词 MJ 二次元', tags: ['MJ','二次元'], category: cat, usageCount: 0, createdAt: Date.now() };
  await addPrompt(demo);
  const list = await getPrompts();
  const fCat = applyFilter(list, '图像生成', '', '');
  const fTag = applyFilter(list, '', '二次元', '');
  const fBoth = applyFilter(list, '图像生成', 'MJ', 'mj');
  console.log('FILTER sizes', list.length, fCat.length, fTag.length, fBoth.length);
}
