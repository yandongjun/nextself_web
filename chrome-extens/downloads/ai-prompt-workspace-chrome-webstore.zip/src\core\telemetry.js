import { apiRequest } from './api.js';
import { authFetch } from './auth.js';
import { getAuthState, getInstallId } from './storage.js';

export async function installPing(meta = {}) {
  const install_id = await getInstallId();
  const body = {
    install_id,
    ext_version: meta.ext_version,
    platform: meta.platform
  };
  await apiRequest('/api/telemetry/install_ping', { method: 'POST', body });
}

export async function sendEvent(type, payload) {
  const install_id = await getInstallId();
  const auth = await getAuthState();
  const body = { type, payload, install_id };
  if (auth?.accessToken) {
    await authFetch('/api/telemetry/event', { method: 'POST', body });
    return;
  }
  await apiRequest('/api/telemetry/event', { method: 'POST', body });
}

