const KEY = 'prompts';
const META_KEY = 'meta';
const RUNTIME_KEY = 'runtimeConfig';
const VERSION = 7;
export const MAX_COUNT = 5;
export const MAX_CONTEXT_MENU_ITEMS = 5;
import { mapCategory } from './category.js';
const UISTATE_KEY = 'uiState';
const AUTH_KEY = 'authState';
const INSTALL_KEY = 'installId';
const TAXONOMY_KEY = 'taxonomy';

function storageGet(area, keys) {
  return new Promise((resolve, reject) => {
    try {
      chrome.storage[area].get(keys, (res) => {
        const err = chrome.runtime?.lastError?.message;
        if (err) return reject(new Error(err));
        resolve(res || {});
      });
    } catch (e) {
      reject(e);
    }
  });
}

function storageSet(area, obj) {
  return new Promise((resolve, reject) => {
    try {
      chrome.storage[area].set(obj, () => {
        const err = chrome.runtime?.lastError?.message;
        if (err) return reject(new Error(err));
        resolve();
      });
    } catch (e) {
      reject(e);
    }
  });
}

function storageRemove(area, keys) {
  return new Promise((resolve, reject) => {
    try {
      chrome.storage[area].remove(keys, () => {
        const err = chrome.runtime?.lastError?.message;
        if (err) return reject(new Error(err));
        resolve();
      });
    } catch (e) {
      reject(e);
    }
  });
}

export async function getPrompts() {
  const localRes = await storageGet('local', [KEY]);
  const local = Array.isArray(localRes[KEY]) ? localRes[KEY] : [];
  if (local && local.length) return local;
  // 兼容读取 sync（若之前写入在 sync）
  const syncRes = await storageGet('sync', [KEY]);
  const syncData = Array.isArray(syncRes[KEY]) ? syncRes[KEY] : [];
  if (syncData && syncData.length) {
    // 将 sync 数据统一迁移到 local，后续读写走 local
    await setPrompts(syncData).catch(() => {});
    return syncData;
  }
  return syncData;
}

export async function setPrompts(list) {
  await storageSet('local', { [KEY]: list });
}

export async function addPrompt(item) {
  const list = await getPrompts();
  const limit = await getLocalPromptLimit();
  if (list.length >= limit) {
    const err = new Error('LIMIT_EXCEEDED');
    err.code = 'LIMIT_EXCEEDED';
    err.limit = limit;
    throw err;
  }
  list.unshift(item);
  await setPrompts(list);
  return list;
}

export function getContextMenuPromptsFromList(list) {
  const items = Array.isArray(list) ? list : [];
  return items
    .filter((p) => p?.showInContextMenu)
    .sort((a, b) => {
      const bt = Number(b?.contextMenuPinnedAt || 0);
      const at = Number(a?.contextMenuPinnedAt || 0);
      if (bt !== at) return bt - at;
      return Number(b?.createdAt || 0) - Number(a?.createdAt || 0);
    })
    .slice(0, MAX_CONTEXT_MENU_ITEMS);
}

export async function togglePromptInContextMenu(id, enabled) {
  const list = await getPrompts();
  const idx = list.findIndex((p) => p?.id === id);
  if (idx < 0) return { list, changed: false, removedId: '' };
  const nextEnabled = !!enabled;
  const current = { ...(list[idx] || {}) };
  const isEnabled = !!current.showInContextMenu;
  if (isEnabled === nextEnabled) return { list, changed: false, removedId: '' };

  let removedId = '';
  if (nextEnabled) {
    const pinned = list
      .filter((p, i) => i !== idx && p?.showInContextMenu)
      .sort((a, b) => {
        const at = Number(a?.contextMenuPinnedAt || 0);
        const bt = Number(b?.contextMenuPinnedAt || 0);
        if (at !== bt) return at - bt;
        return Number(a?.createdAt || 0) - Number(b?.createdAt || 0);
      });
    if (pinned.length >= MAX_CONTEXT_MENU_ITEMS) {
      const oldest = pinned[0];
      removedId = String(oldest?.id || '');
      const oldestIdx = list.findIndex((p) => p?.id === removedId);
      if (oldestIdx >= 0) {
        list[oldestIdx] = {
          ...list[oldestIdx],
          showInContextMenu: false,
          contextMenuPinnedAt: 0
        };
      }
    }
    list[idx] = {
      ...current,
      showInContextMenu: true,
      contextMenuPinnedAt: Date.now()
    };
  } else {
    list[idx] = {
      ...current,
      showInContextMenu: false,
      contextMenuPinnedAt: 0
    };
  }
  await setPrompts(list);
  return { list, changed: true, removedId };
}

export async function getRuntimeConfig() {
  const res = await storageGet('local', [RUNTIME_KEY]);
  const cfg = res[RUNTIME_KEY];
  return cfg && typeof cfg === 'object' ? cfg : {};
}

export async function setRuntimeConfig(patch) {
  const prev = await getRuntimeConfig();
  const next = { ...(prev || {}), ...(patch || {}) };
  await storageSet('local', { [RUNTIME_KEY]: next });
  return next;
}

export async function getLocalPromptLimit() {
  const cfg = await getRuntimeConfig().catch(() => ({}));
  const limit = Number(cfg?.promptLimit || 0);
  if (Number.isFinite(limit) && limit > 0) return Math.floor(limit);
  return MAX_COUNT;
}

export async function setLocalPromptLimit(limit) {
  const n = Number(limit || 0);
  if (!Number.isFinite(n) || n <= 0) return;
  await setRuntimeConfig({ promptLimit: Math.floor(n), promptLimitUpdatedAt: Date.now() });
}

export async function updatePrompt(id, patch) {
  const list = await getPrompts();
  const idx = list.findIndex((p) => p.id === id);
  if (idx < 0) return list;
  list[idx] = { ...list[idx], ...(patch || {}) };
  await setPrompts(list);
  return list;
}

export async function incrementUsage(id) {
  const list = await getPrompts();
  const idx = list.findIndex((p) => p.id === id);
  if (idx >= 0) {
    const p = list[idx];
    list[idx] = { ...p, usageCount: (p.usageCount || 0) + 1, lastUsedAt: Date.now() };
    await setPrompts(list);
  }
  return list;
}

export function subscribe(callback) {
  const handler = (changes, area) => {
    if ((area === 'local' || area === 'sync') && changes[KEY]) {
      const list = Array.isArray(changes[KEY].newValue) ? changes[KEY].newValue : [];
      callback(list);
    }
  };
  chrome.storage.onChanged.addListener(handler);
  return () => chrome.storage.onChanged.removeListener(handler);
}

export async function getMeta() {
  const res = await storageGet('local', [META_KEY]);
  return res[META_KEY] || { version: 1 };
}

export async function setMeta(meta) {
  await storageSet('local', { [META_KEY]: meta });
}

export async function getSyncCursor(userId) {
  const meta = await getMeta();
  const cursors = (meta && typeof meta === 'object' ? meta.syncCursors : null) || {};
  const key = String(userId || '');
  const v = Number(cursors[key] || 0);
  return Number.isFinite(v) && v > 0 ? v : 0;
}

export async function setSyncCursor(userId, cursor) {
  const meta = await getMeta();
  const base = meta && typeof meta === 'object' ? meta : { version: 1 };
  const cursors = (base && typeof base === 'object' ? base.syncCursors : null) || {};
  const next = { ...cursors };
  next[String(userId || '')] = Number(cursor || 0);
  await setMeta({ ...base, syncCursors: next });
}

export async function getUIState() {
  const res = await storageGet('local', [UISTATE_KEY]);
  return res[UISTATE_KEY] || {};
}

export async function setUIState(state) {
  const prev = await getUIState();
  const next = { ...(prev || {}), ...(state || {}) };
  await storageSet('local', { [UISTATE_KEY]: next }).catch(() => {});
}

export async function getAuthState() {
  const res = await storageGet('local', [AUTH_KEY]);
  return res[AUTH_KEY] || {};
}

export async function setAuthState(state) {
  const prev = await getAuthState();
  const next = { ...(prev || {}), ...(state || {}) };
  await storageSet('local', { [AUTH_KEY]: next });
}

export async function clearAuthState() {
  await storageRemove('local', [AUTH_KEY]);
}

export async function getInstallId() {
  const res = await storageGet('local', [INSTALL_KEY]);
  const existing = res[INSTALL_KEY] || '';
  if (existing) return existing;
  const id = crypto.randomUUID();
  await storageSet('local', { [INSTALL_KEY]: id });
  return id;
}

export async function getTaxonomy() {
  const res = await storageGet('local', [TAXONOMY_KEY]);
  return res[TAXONOMY_KEY] || null;
}

export async function setTaxonomy(taxonomy) {
  await storageSet('local', { [TAXONOMY_KEY]: taxonomy });
}

function buildDefaultTaxonomyCategories() {
  return [
    {
      name: '工作效率',
      children: ['会议纪要整理', '长文摘要', 'PPT大纲', '方案编写']
    },
    {
      name: '构思创意',
      children: ['头脑风暴', '点子生成', '命名', '角度发掘']
    },
    {
      name: '图像提示词',
      children: ['Midjourney', 'Stable Diffusion', 'Flux', 'CG', '3D', '插画', '摄影']
    },
    {
      name: '视频提示词',
      children: ['视频脚本', '分镜', '运镜', 'Runway', 'Sora', '短视频', '旁白']
    },
    {
      name: '写作润色',
      children: ['邮件', '报告', '文案', '总结', '风格改写']
    },
    {
      name: '对话模拟',
      children: ['模拟面试', '客户沟通', '辩论演练', '角色扮演']
    },
    {
      name: '开发技术',
      children: ['代码规范', '产品经理', '全栈高级工程师', '后端工程师']
    },
    {
      name: '其他',
      children: []
    }
  ];
}

function normalizeTaxonomy(taxonomy) {
  const defaults = buildDefaultTaxonomyCategories();
  const current = taxonomy && Array.isArray(taxonomy.categories) ? taxonomy.categories : [];
  const map = new Map();
  for (const item of current) {
    const name = String(item?.name || '').trim();
    if (!name) continue;
    const children = Array.isArray(item?.children) ? item.children.map((x) => String(x || '').trim()).filter(Boolean) : [];
    map.set(name, { name, children: Array.from(new Set(children)) });
  }
  for (const item of defaults) {
    if (!map.has(item.name)) {
      map.set(item.name, { name: item.name, children: [...item.children] });
      continue;
    }
    const prev = map.get(item.name);
    prev.children = Array.from(new Set([...(prev.children || []), ...item.children]));
    map.set(item.name, prev);
  }
  const ordered = defaults
    .map((item) => map.get(item.name))
    .filter(Boolean);
  for (const [name, item] of map.entries()) {
    if (!defaults.some((x) => x.name === name)) ordered.push(item);
  }
  return { version: 1, categories: ordered };
}

export function defaultTaxonomy() {
  return {
    version: 1,
    categories: buildDefaultTaxonomyCategories()
  };
}

export async function ensureTaxonomy() {
  const existing = await getTaxonomy();
  const next = normalizeTaxonomy(existing);
  if (!existing || JSON.stringify(existing) !== JSON.stringify(next)) {
    await setTaxonomy(next);
  }
  return next;
}

export async function migrateIfNeeded() {
  const meta = await getMeta();
  if ((meta.version || 1) >= VERSION) return;
  const list = await getPrompts();
  const updated = list.map((p) => {
    let obj = { ...p };
    if (!obj.category) {
      const cat = mapCategory(obj.content || '', obj.tags || []);
      obj.category = cat;
    }
    if (obj.favorite === undefined) obj.favorite = false;
    if (['图像生成', '文案写作', '代码辅助', '数据分析', '未分类'].includes(obj.category)) {
      obj.category = mapCategory(obj.content || '', obj.tags || []);
    }
    if (!Array.isArray(obj.tags)) obj.tags = [];
    if (!Array.isArray(obj.tagsEn)) obj.tagsEn = [];
    if (!Array.isArray(obj.categories)) obj.categories = obj.category ? [obj.category] : [];
    if (typeof obj.title !== 'string') obj.title = '';
    if (typeof obj.titleEn !== 'string') obj.titleEn = '';
    if (typeof obj.translationZh !== 'string') obj.translationZh = '';
    if (typeof obj.showInContextMenu !== 'boolean') obj.showInContextMenu = false;
    if (typeof obj.contextMenuPinnedAt !== 'number') obj.contextMenuPinnedAt = 0;
    if (typeof obj.syncState !== 'string') {
      if (obj.aiQuotaExceeded) obj.syncState = 'blocked';
      else if (!obj.serverPromptId) obj.syncState = 'pending';
      else obj.syncState = 'synced';
    }
    if (typeof obj.syncAttemptCount !== 'number') obj.syncAttemptCount = 0;
    if (typeof obj.lastSyncAttemptAt !== 'number') obj.lastSyncAttemptAt = 0;
    if (typeof obj.syncedAt !== 'number') obj.syncedAt = 0;
    return obj;
  });
  await setPrompts(updated);
  await ensureTaxonomy();
  await setMeta({ version: VERSION });
  return updated;
}
