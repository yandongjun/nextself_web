function pushParagraph(out, text) {
  const t = text.trim();
  if (!t) return;
  out.push({ type: 'p', text: t });
}

function parseMarkdown(md) {
  // 轻量 Markdown 解析器（块级）：支持标题、无序/有序列表、引用、代码块、分割线与段落。
  // 设计目标：不引入第三方库，避免 XSS（仅用 textContent 写入），用于“提示词排版更清晰”。
  const lines = String(md || '').split(/\r?\n/);
  const blocks = [];
  let i = 0;
  let para = [];
  const flushPara = () => {
    if (para.length) {
      pushParagraph(blocks, para.join('\n'));
      para = [];
    }
  };
  while (i < lines.length) {
    const line = lines[i];
    if (/^\s*```/.test(line)) {
      flushPara();
      const buf = [];
      i += 1;
      while (i < lines.length && !/^\s*```/.test(lines[i])) {
        buf.push(lines[i]);
        i += 1;
      }
      i += 1;
      blocks.push({ type: 'code', text: buf.join('\n') });
      continue;
    }
    const hr = /^\s*---\s*$/.test(line);
    if (hr) {
      flushPara();
      blocks.push({ type: 'hr' });
      i += 1;
      continue;
    }
    const h = /^(#{1,6})\s+(.*)$/.exec(line);
    if (h) {
      flushPara();
      blocks.push({ type: 'h', level: h[1].length, text: (h[2] || '').trim() });
      i += 1;
      continue;
    }
    if (/^\s*>\s?/.test(line)) {
      flushPara();
      const buf = [];
      while (i < lines.length && /^\s*>\s?/.test(lines[i])) {
        buf.push(lines[i].replace(/^\s*>\s?/, ''));
        i += 1;
      }
      blocks.push({ type: 'quote', text: buf.join('\n').trim() });
      continue;
    }
    if (/^\s*([-*])\s+/.test(line)) {
      flushPara();
      const items = [];
      while (i < lines.length && /^\s*([-*])\s+/.test(lines[i])) {
        items.push(lines[i].replace(/^\s*([-*])\s+/, '').trim());
        i += 1;
      }
      blocks.push({ type: 'ul', items });
      continue;
    }
    if (/^\s*\d+\.\s+/.test(line)) {
      flushPara();
      const items = [];
      while (i < lines.length && /^\s*\d+\.\s+/.test(lines[i])) {
        items.push(lines[i].replace(/^\s*\d+\.\s+/, '').trim());
        i += 1;
      }
      blocks.push({ type: 'ol', items });
      continue;
    }
    if (!line.trim()) {
      flushPara();
      i += 1;
      continue;
    }
    para.push(line);
    i += 1;
  }
  flushPara();
  return blocks;
}

function renderInline(text, parent) {
  const s = String(text || '');
  let i = 0;
  while (i < s.length) {
    const b = s.indexOf('**', i);
    const c = s.indexOf('`', i);
    let next = -1;
    let kind = '';
    if (b >= 0 && (c < 0 || b < c)) {
      next = b;
      kind = 'bold';
    } else if (c >= 0) {
      next = c;
      kind = 'code';
    }
    if (next < 0) {
      parent.append(document.createTextNode(s.slice(i)));
      break;
    }
    if (next > i) parent.append(document.createTextNode(s.slice(i, next)));
    if (kind === 'bold') {
      const end = s.indexOf('**', next + 2);
      if (end < 0) {
        parent.append(document.createTextNode(s.slice(next)));
        break;
      }
      const strong = document.createElement('strong');
      strong.textContent = s.slice(next + 2, end);
      parent.append(strong);
      i = end + 2;
    } else {
      const end = s.indexOf('`', next + 1);
      if (end < 0) {
        parent.append(document.createTextNode(s.slice(next)));
        break;
      }
      const code = document.createElement('code');
      code.textContent = s.slice(next + 1, end);
      parent.append(code);
      i = end + 1;
    }
  }
}

export function renderMarkdown(md, container) {
  // 将 Markdown 渲染为 DOM（安全：不解析任何 HTML），配合 options.css 的 .content.md 做排版。
  container.innerHTML = '';
  const blocks = parseMarkdown(md);
  for (const b of blocks) {
    if (b.type === 'h') {
      const el = document.createElement(`h${Math.min(6, Math.max(1, b.level))}`);
      renderInline(b.text, el);
      container.append(el);
    } else if (b.type === 'p') {
      const el = document.createElement('p');
      renderInline(b.text, el);
      container.append(el);
    } else if (b.type === 'code') {
      const pre = document.createElement('pre');
      const code = document.createElement('code');
      code.textContent = b.text;
      pre.append(code);
      container.append(pre);
    } else if (b.type === 'quote') {
      const el = document.createElement('blockquote');
      renderInline(b.text, el);
      container.append(el);
    } else if (b.type === 'ul') {
      const ul = document.createElement('ul');
      for (const it of b.items) {
        const li = document.createElement('li');
        renderInline(it, li);
        ul.append(li);
      }
      container.append(ul);
    } else if (b.type === 'ol') {
      const ol = document.createElement('ol');
      for (const it of b.items) {
        const li = document.createElement('li');
        renderInline(it, li);
        ol.append(li);
      }
      container.append(ol);
    } else if (b.type === 'hr') {
      container.append(document.createElement('hr'));
    }
  }
  if (!blocks.length) {
    const el = document.createElement('p');
    el.textContent = '';
    container.append(el);
  }
}
