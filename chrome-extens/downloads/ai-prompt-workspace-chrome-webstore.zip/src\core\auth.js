import { apiRequest } from './api.js';
import { clearAuthState, getAuthState, setAuthState } from './storage.js';

function decodeJwtExp(token) {
  try {
    const part = token.split('.')[1] || '';
    const b64 = part.replace(/-/g, '+').replace(/_/g, '/');
    const pad = b64.length % 4 ? '='.repeat(4 - (b64.length % 4)) : '';
    const json = atob(b64 + pad);
    const obj = JSON.parse(json);
    const exp = Number(obj.exp || 0);
    return exp ? exp * 1000 : 0;
  } catch {
    return 0;
  }
}

export async function getSession() {
  const s = await getAuthState();
  if (!s || !s.accessToken) return null;
  return s;
}

export async function setSession(payload) {
  const accessToken = payload?.access_token || payload?.accessToken || '';
  const refreshToken = payload?.refresh_token || payload?.refreshToken || '';
  const user = payload?.user || null;
  const accessExp = accessToken ? decodeJwtExp(accessToken) : 0;
  await setAuthState({ user, accessToken, refreshToken, accessExp });
  return await getAuthState();
}

export async function logout() {
  const s = await getAuthState();
  const refreshToken = s.refreshToken;
  if (refreshToken) {
    await apiRequest('/api/auth/logout', { method: 'POST', body: { refresh_token: refreshToken } });
  }
  await clearAuthState();
}

export async function register(email, password) {
  const res = await apiRequest('/api/auth/register', { method: 'POST', body: { email, password } });
  if (!res.ok) return res;
  await setSession(res.data);
  return res;
}

export async function login(email, password) {
  const res = await apiRequest('/api/auth/login', { method: 'POST', body: { email, password } });
  if (!res.ok) return res;
  await setSession(res.data);
  return res;
}

export async function ensureAccessToken() {
  const s = await getAuthState();
  if (!s?.accessToken) return '';
  const exp = Number(s.accessExp || 0);
  const now = Date.now();
  if (exp && exp - now > 60_000) return s.accessToken;
  const refreshToken = s.refreshToken;
  if (!refreshToken) return s.accessToken;
  const res = await apiRequest('/api/auth/refresh', { method: 'POST', body: { refresh_token: refreshToken } });
  if (!res.ok) return s.accessToken;
  const accessToken = res.data?.access_token || res.data?.accessToken || '';
  const accessExp = accessToken ? decodeJwtExp(accessToken) : 0;
  await setAuthState({ accessToken, accessExp });
  return accessToken;
}

export async function authFetch(path, { method = 'GET', body, headers = {} } = {}) {
  const accessToken = await ensureAccessToken();
  const h = { ...headers };
  if (accessToken) h.Authorization = `Bearer ${accessToken}`;
  let res = await apiRequest(path, { method, headers: h, body });
  if (res.status === 401) {
    const accessToken2 = await ensureAccessToken();
    const h2 = { ...headers };
    if (accessToken2) h2.Authorization = `Bearer ${accessToken2}`;
    res = await apiRequest(path, { method, headers: h2, body });
  }
  return res;
}

