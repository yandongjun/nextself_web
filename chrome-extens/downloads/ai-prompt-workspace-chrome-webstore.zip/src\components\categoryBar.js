export function mountCategoryBar(container, onCategoryChange, options = {}) {
  let current = '';
  const scroll = container.querySelector('#categories-scroll');
  let countMap = new Map();
  let allCount = null;
  let categories = Array.isArray(options.categories) ? options.categories.filter(Boolean) : [];
  const allLabel = options.allLabel || (() => '全部分类');
  const categoryLabel = options.categoryLabel || ((value) => value);
  const getCategories = () => categories;
  function render() {
    scroll.innerHTML = '';
    const allBtn = document.createElement('button');
    allBtn.className = 'cat-all';
    const allText = allLabel();
    allBtn.textContent = typeof allCount === 'number' ? `${allText} (${allCount})` : allText;
    if (!current) allBtn.classList.add('active');
    allBtn.onclick = () => {
      current = '';
      onCategoryChange?.('');
      sync();
    };
    scroll.append(allBtn);
    for (const cat of getCategories()) {
      const btn = document.createElement('button');
      btn.className = 'cat';
      const c = countMap.get(cat);
      const label = categoryLabel(cat);
      btn.textContent = typeof c === 'number' ? `${label} (${c})` : label;
      btn.dataset.cat = cat;
      if (cat === current) btn.classList.add('active');
      btn.onclick = () => {
        if (current === cat) {
          current = '';
          onCategoryChange?.('');
        } else {
          current = cat;
          onCategoryChange?.(cat);
        }
        sync();
      };
      scroll.append(btn);
    }
    sync();
  }
  function sync() {
    container.querySelectorAll('.cat').forEach((b) => {
      const c = b.dataset.cat || '';
      if (c === current) b.classList.add('active');
      else b.classList.remove('active');
    });
    const allBtn = container.querySelector('.cat-all');
    if (allBtn) {
      const allText = allLabel();
      allBtn.textContent = typeof allCount === 'number' ? `${allText} (${allCount})` : allText;
      if (!current) allBtn.classList.add('active');
      else allBtn.classList.remove('active');
    }
  };
  render();
  return {
    setActive(cat) {
      current = cat || '';
      sync();
    },
    setCounts(nextMap, nextAllCount) {
      countMap = nextMap instanceof Map ? nextMap : new Map();
      allCount = typeof nextAllCount === 'number' ? nextAllCount : null;
      render();
    },
    setCategories(nextCategories) {
      categories = Array.isArray(nextCategories) ? nextCategories.filter(Boolean) : [];
      render();
    },
  };
}
