import { sendEvent } from '../core/telemetry.js';

async function copyToClipboard(text) {
  const t = String(text || '');
  try {
    await navigator.clipboard.writeText(t);
    return true;
  } catch {}
  try {
    const ta = document.createElement('textarea');
    ta.value = t;
    ta.style.position = 'fixed';
    ta.style.left = '-9999px';
    ta.style.top = '0';
    document.body.append(ta);
    ta.focus();
    ta.select();
    const ok = document.execCommand('copy');
    ta.remove();
    return ok;
  } catch {
    return false;
  }
}

export function renderList(container, list, onCopied, options = {}) {
  const safeList = Array.isArray(list) ? list : [];
  const t = options.t || ((key) => key);
  const getTagLabel = options.tagLabel || ((tag) => tag);
  const getTitleLabel = options.titleLabel || ((item) => item.title || (item.content || '').split(/\r?\n/)[0]?.trim() || t('unnamedPrompt'));
  const showTranslation = typeof options.showTranslation === 'function' ? options.showTranslation : ((item) => !!item?.translationZh);
  const onToggleContextMenuPin = typeof options.onToggleContextMenuPin === 'function' ? options.onToggleContextMenuPin : null;
  container.innerHTML = '';
  for (const item of safeList) {
    const card = document.createElement('div');
    card.className = 'item';
    const title = document.createElement('div');
    title.className = 'title';
    title.textContent = getTitleLabel(item);
    const content = document.createElement('div');
    content.className = 'content one-line';
    content.textContent = item.content;
    content.title = item.content;
    content.onclick = () => {
      if (content.classList.contains('one-line')) {
        content.classList.remove('one-line');
        content.style.whiteSpace = 'pre-wrap';
        content.style.wordBreak = 'break-word';
      } else {
        content.classList.add('one-line');
        content.style.whiteSpace = '';
        content.style.wordBreak = '';
      }
    };
    const meta = document.createElement('div');
    meta.className = 'meta';
    if (item.syncState === 'syncing') {
      const b = document.createElement('span');
      b.className = 'badge';
      b.textContent = t('syncing');
      meta.append(b);
    }
    if (item.syncState === 'pending' && !item.aiQuotaExceeded) {
      const b = document.createElement('span');
      b.className = 'badge';
      b.textContent = t('pendingSync');
      meta.append(b);
    }
    if (item.syncState === 'blocked' && !item.aiQuotaExceeded) {
      const b = document.createElement('span');
      b.className = 'badge';
      b.textContent = t('blocked');
      if (item.aiError) b.title = String(item.aiError);
      meta.append(b);
    }
    const tags = Array.isArray(item.tags) ? item.tags : [];
    for (let i = 0; i < tags.length; i += 1) {
      const tag = tags[i];
      const b = document.createElement('span');
      b.className = 'badge';
      b.textContent = getTagLabel(tag, item, i);
      meta.append(b);
    }
    if (item.aiPending) {
      const b = document.createElement('span');
      b.className = 'badge';
      b.textContent = t('aiProcessing');
      meta.append(b);
    }
    if (item.aiQuotaExceeded) {
      const b = document.createElement('span');
      b.className = 'badge';
      b.textContent = t('aiQuotaExceeded');
      meta.append(b);
    }
    const isNetwork = item.aiError && (String(item.aiError).toLowerCase().includes('network') || String(item.aiError).includes('网络'));
    if (item.aiError && !item.aiQuotaExceeded && !(item.syncState === 'pending' && isNetwork)) {
      const b = document.createElement('span');
      b.className = 'badge';
      b.textContent = t('aiFailed');
      b.title = String(item.aiError);
      meta.append(b);
    }
    if (item.showInContextMenu) {
      const b = document.createElement('span');
      b.className = 'badge';
      b.textContent = t('contextMenuPinned');
      meta.append(b);
    }
    const copyBtn = document.createElement('button');
    copyBtn.className = 'use';
    copyBtn.textContent = t('copy');
    copyBtn.onclick = async () => {
      const ok = await copyToClipboard(item.content || '');
      if (ok) {
        copyBtn.textContent = t('copied');
        setTimeout(() => (copyBtn.textContent = t('copy')), 800);
        sendEvent('prompt_copy', { local_prompt_id: item.id }).catch(() => {});
        onCopied?.(item);
      } else {
        copyBtn.textContent = t('copyFailed');
        setTimeout(() => (copyBtn.textContent = t('copy')), 1200);
      }
    };
    meta.append(copyBtn);
    if (onToggleContextMenuPin) {
      const pinBtn = document.createElement('button');
      pinBtn.className = 'use';
      pinBtn.textContent = item.showInContextMenu ? t('unpinFromContextMenu') : t('pinToContextMenu');
      pinBtn.onclick = async () => {
        pinBtn.disabled = true;
        try {
          await onToggleContextMenuPin(item);
        } finally {
          pinBtn.disabled = false;
        }
      };
      meta.append(pinBtn);
    }
    if (item.translationZh && showTranslation(item)) {
      const tr = document.createElement('div');
      tr.className = 'translation one-line';
      tr.textContent = item.translationZh;
      tr.title = item.translationZh;
      tr.onclick = () => {
        if (tr.classList.contains('one-line')) {
          tr.classList.remove('one-line');
        } else {
          tr.classList.add('one-line');
        }
      };
      card.append(title, content, tr, meta);
    } else {
      card.append(title, content, meta);
    }
    container.append(card);
  }
}
