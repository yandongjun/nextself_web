import { addPrompt, getLocalPromptLimit } from '../core/storage.js';
import { suggestTags } from '../core/tagger.js';
import { mapCategory } from '../core/category.js';
import { classifyPrompt } from '../core/aiClassify.js';
import { documentLang, getLang, t } from '../core/i18n.js';
import { syncPromptLimit } from '../core/quota.js';

export function mountAddModal(root, onClose, onAdded) {
  let lang = 'zh';
  const tt = (key, vars) => t(lang, key, vars);
  root.innerHTML = '';
  const overlay = document.createElement('div');
  overlay.className = 'modal';
  const card = document.createElement('div');
  card.className = 'card';
  const title = document.createElement('h3');
  title.textContent = tt('newPromptTitle');
  const textarea = document.createElement('textarea');
  const actions = document.createElement('div');
  actions.className = 'actions';
  const cancel = document.createElement('button');
  cancel.className = 'btn';
  cancel.textContent = tt('cancel');
  const submit = document.createElement('button');
  submit.className = 'btn primary';
  submit.textContent = tt('submit');
  actions.append(cancel, submit);
  card.append(title, textarea, actions);
  overlay.append(card);
  root.append(overlay);
  root.classList.add('show');
  textarea.focus();
  getLang().then((value) => {
    lang = value;
    document.documentElement.lang = documentLang(lang);
    title.textContent = tt('newPromptTitle');
    cancel.textContent = tt('cancel');
    submit.textContent = tt('submit');
  }).catch(() => {});

  const close = () => {
    root.classList.remove('show');
    root.innerHTML = '';
    onClose?.();
  };
  cancel.onclick = () => close();
  overlay.onclick = (e) => {
    if (e.target === overlay) close();
  };
  submit.onclick = async () => {
    try {
      const content = (textarea.value || '').trim();
      if (!content) {
        close();
        return;
      }
      const tags = suggestTags(content);
      const category = mapCategory(content, tags);
      const item = {
        id: crypto.randomUUID(),
        title: '',
        titleEn: '',
        translationZh: '',
        content,
        tags,
        tagsEn: [],
        category,
        categories: [category],
        syncState: 'pending',
        syncAttemptCount: 0,
        lastSyncAttemptAt: 0,
        syncedAt: 0,
        aiPending: false,
        usageCount: 0,
        showInContextMenu: false,
        contextMenuPinnedAt: 0,
        createdAt: Date.now()
      };
      await syncPromptLimit().catch(() => null);
      const list = await addPrompt(item);
      classifyPrompt(item.id, item.content, { list }).catch(() => {});
      onAdded?.(list);
      close();
    } catch (e) {
      const code = String(e?.code || e?.message || e);
      const limit = Number(e?.limit || 0) || await getLocalPromptLimit();
      const message = code === 'LIMIT_EXCEEDED' ? tt('limitExceeded', { max: limit }) : String(e?.message || e);
      alert(tt('saveFailed', { message }));
    }
  };
}
