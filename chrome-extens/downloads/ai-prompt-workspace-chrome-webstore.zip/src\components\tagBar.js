import { computeTagIndex } from '../core/filter.js';

export function mountTagBar(container, tagScroll, listProvider, onTagChange) {
  let currentTag = '';
  function renderTags() {
    tagScroll.innerHTML = '';
    const list = listProvider();
    const idx = computeTagIndex(list);
    const arr = Array.from(idx.entries()).sort((a, b) => b[1] - a[1]);
    for (const [tag, count] of arr) {
      const btn = document.createElement('button');
      btn.className = 'tag';
      btn.textContent = tag;
      btn.dataset.tag = tag;
      if (tag === currentTag) btn.classList.add('active');
      btn.title = `使用次数 ${count}`;
      btn.onclick = () => {
        if (currentTag === tag) {
          currentTag = '';
          onTagChange?.('');
        } else {
          currentTag = tag;
          onTagChange?.(tag);
        }
        syncActive();
      };
      tagScroll.append(btn);
    }
  }
  function syncActive() {
    tagScroll.querySelectorAll('.tag').forEach((b) => {
      const t = b.dataset.tag || '';
      if (t === currentTag) {
        b.classList.add('active');
      } else {
        b.classList.remove('active');
      }
    });
  }
  renderTags();
  return {
    setActive(tag) {
      currentTag = tag || '';
      syncActive();
    },
    refresh() {
      renderTags();
    }
  };
}

export function mountTagSearch(toggleBtn, inputEl, tagScroll) {
  toggleBtn.onclick = () => {
    inputEl.classList.toggle('show');
    if (inputEl.classList.contains('show')) inputEl.focus();
  };
  inputEl.addEventListener('input', () => {
    const q = (inputEl.value || '').trim().toLowerCase();
    tagScroll.querySelectorAll('.tag').forEach((btn) => {
      const t = (btn.textContent || '').toLowerCase();
      if (!q) {
        btn.style.outline = '';
      } else if (t.includes(q)) {
        btn.style.outline = '2px solid #93c5fd';
      } else {
        btn.style.outline = '';
      }
    });
  });
}
