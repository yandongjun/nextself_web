import { addPrompt, getContextMenuPromptsFromList, getLocalPromptLimit, getPrompts, incrementUsage, migrateIfNeeded } from './src/core/storage.js';
import { suggestTags } from './src/core/tagger.js';
import { mapCategory } from './src/core/category.js';
import { classifyPrompt } from './src/core/aiClassify.js';
import { installPing, sendEvent } from './src/core/telemetry.js';
import { getLang, t } from './src/core/i18n.js';
import { syncPromptLimit } from './src/core/quota.js';

const SYNC_ALARM = 'sync_pending_prompts';
const ADD_SELECTED_PROMPT_MENU_ID = 'add-selected-prompt';
const INSERT_PROMPT_ROOT_MENU_ID = 'insert-saved-prompt';
const INSERT_PROMPT_MENU_PREFIX = 'insert-saved-prompt:';
const EMPTY_PROMPT_MENU_ID = 'insert-saved-prompt:empty';
let syncing = false;
let menuRebuildChain = Promise.resolve();

function normalizePromptContent(text) {
  return String(text || '').replace(/\r\n/g, '\n').trim();
}

function buildPromptMenuTitle(prompt, lang = 'zh') {
  const preferred = lang === 'en'
    ? (prompt?.titleEn || prompt?.title || prompt?.content || '')
    : (prompt?.title || prompt?.titleEn || prompt?.content || '');
  const raw = String(preferred).replace(/\s+/g, ' ').trim();
  if (!raw) return t(lang, 'unnamedPrompt');
  return raw.length > 36 ? `${raw.slice(0, 36)}...` : raw;
}

function removeAllMenus() {
  return new Promise((resolve, reject) => {
    chrome.contextMenus.removeAll(() => {
      const err = chrome.runtime?.lastError;
      if (err) return reject(new Error(err.message || String(err)));
      resolve();
    });
  });
}

function createMenu(item) {
  return new Promise((resolve, reject) => {
    chrome.contextMenus.create(item, () => {
      const err = chrome.runtime?.lastError;
      if (err) return reject(new Error(err.message || String(err)));
      resolve();
    });
  });
}

async function doRebuildContextMenus() {
  const lang = await getLang().catch(() => 'zh');
  try {
    await removeAllMenus();
  } catch {}
  try {
    await createMenu({
      id: ADD_SELECTED_PROMPT_MENU_ID,
      title: t(lang, 'addSelectedPrompt'),
      contexts: ['selection']
    });
    await createMenu({
      id: INSERT_PROMPT_ROOT_MENU_ID,
      title: t(lang, 'insertSavedPrompt'),
      contexts: ['editable']
    });
    const prompts = await getPrompts().catch(() => []);
    const list = getContextMenuPromptsFromList(prompts);
    if (!list.length) {
      await createMenu({
        id: EMPTY_PROMPT_MENU_ID,
        parentId: INSERT_PROMPT_ROOT_MENU_ID,
        title: t(lang, 'noSavedPrompt'),
        contexts: ['editable'],
        enabled: false
      });
      return;
    }
    for (const item of list) {
      await createMenu({
        id: `${INSERT_PROMPT_MENU_PREFIX}${item.id}`,
        parentId: INSERT_PROMPT_ROOT_MENU_ID,
        title: buildPromptMenuTitle(item, lang),
        contexts: ['editable']
      });
    }
  } catch {}
}

function rebuildContextMenus() {
  menuRebuildChain = menuRebuildChain.catch(() => {}).then(() => doRebuildContextMenus());
  return menuRebuildChain;
}

async function insertPromptIntoEditable(tabId, promptText, frameId) {
  if (!tabId) return false;
  const target = frameId >= 0 ? { tabId, frameIds: [frameId] } : { tabId };
  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target,
      args: [String(promptText || '')],
      func: (text) => {
        const inputTypes = new Set(['text', 'search', 'url', 'tel', 'email', 'password', 'number']);
        const el = document.activeElement;
        const fireInput = (node) => {
          node.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text }));
          node.dispatchEvent(new Event('change', { bubbles: true }));
        };
        if (el instanceof HTMLTextAreaElement || (el instanceof HTMLInputElement && inputTypes.has((el.type || 'text').toLowerCase()))) {
          const start = typeof el.selectionStart === 'number' ? el.selectionStart : el.value.length;
          const end = typeof el.selectionEnd === 'number' ? el.selectionEnd : el.value.length;
          el.focus();
          if (typeof el.setRangeText === 'function') {
            el.setRangeText(text, start, end, 'end');
          } else {
            el.value = `${el.value.slice(0, start)}${text}${el.value.slice(end)}`;
          }
          fireInput(el);
          return true;
        }
        if (el && el.isContentEditable) {
          el.focus();
          const sel = window.getSelection ? window.getSelection() : null;
          if (sel && sel.rangeCount) {
            const range = sel.getRangeAt(0);
            range.deleteContents();
            const node = document.createTextNode(text);
            range.insertNode(node);
            range.setStartAfter(node);
            range.collapse(true);
            sel.removeAllRanges();
            sel.addRange(range);
          } else {
            document.execCommand('insertText', false, text);
          }
          fireInput(el);
          return true;
        }
        return false;
      }
    });
    return !!result;
  } catch {
    return false;
  }
}

async function showSavedHint(tabId, message, action) {
  if (!tabId) return;
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      args: [String(message || ''), action || null],
      func: (msg, act) => {
        const id = '__prompt_collector_toast__';
        const existing = document.getElementById(id);
        if (existing) existing.remove();
        const el = document.createElement('div');
        el.id = id;
        el.textContent = msg;
        el.style.position = 'fixed';
        el.style.zIndex = '2147483647';
        el.style.background = 'rgba(15, 23, 42, 0.92)';
        el.style.color = '#fff';
        el.style.padding = '10px 12px';
        el.style.borderRadius = '12px';
        el.style.fontSize = '13px';
        el.style.lineHeight = '1.2';
        el.style.boxShadow = '0 10px 30px rgba(0,0,0,0.25)';
        el.style.maxWidth = '280px';
        el.style.wordBreak = 'break-word';
        el.style.opacity = '0';
        el.style.transform = 'translateY(-6px)';
        el.style.transition = 'opacity 120ms ease, transform 120ms ease';
        if (act && act.type === 'open_options' && act.focusId) {
          el.style.cursor = 'pointer';
          el.onclick = () => {
            try {
              chrome.runtime.sendMessage({ type: 'open_options', focusId: String(act.focusId) });
            } catch {}
            try { el.remove(); } catch {}
          };
        }

        const margin = 12;
        let left = window.innerWidth - margin;
        let top = margin;
        try {
          const sel = window.getSelection ? window.getSelection() : null;
          if (sel && sel.rangeCount) {
            const rect = sel.getRangeAt(0).getBoundingClientRect();
            if (rect && rect.width + rect.height > 0) {
              left = rect.left;
              top = rect.bottom + 10;
            }
          }
        } catch {}
        document.documentElement.append(el);
        const w = el.getBoundingClientRect().width || 280;
        const h = el.getBoundingClientRect().height || 44;
        if (left + w + margin > window.innerWidth) left = window.innerWidth - w - margin;
        if (left < margin) left = margin;
        if (top + h + margin > window.innerHeight) top = Math.max(margin, window.innerHeight - h - margin);
        if (top < margin) top = margin;
        el.style.left = `${Math.round(left)}px`;
        el.style.top = `${Math.round(top)}px`;
        requestAnimationFrame(() => {
          el.style.opacity = '1';
          el.style.transform = 'translateY(0)';
        });
        setTimeout(() => {
          el.style.opacity = '0';
          el.style.transform = 'translateY(-6px)';
          setTimeout(() => el.remove(), 160);
        }, 1200);
      }
    });
    return;
  } catch {}
  try {
    chrome.action?.setBadgeBackgroundColor({ color: '#16a34a' });
    chrome.action?.setBadgeText({ text: '✓' });
    setTimeout(() => chrome.action?.setBadgeText({ text: '' }), 1200);
  } catch {}
}

async function addPromptFromText(tabId, rawText, source) {
  try {
    const lang = await getLang().catch(() => 'zh');
    const text = normalizePromptContent(rawText);
    if (!text) return { ok: false, reason: 'empty' };
    await migrateIfNeeded();
    const existing = await getPrompts();
    const found = existing.find((p) => normalizePromptContent(p?.content) === text);
    if (found) {
      showSavedHint(tabId, t(lang, 'promptAlreadyExists'), { type: 'open_options', focusId: found.id }).catch(() => {});
      sendEvent('prompt_create_duplicate', { source, content_length: text.length }).catch(() => {});
      return { ok: false, reason: 'duplicate' };
    }
    const tags = suggestTags(text);
    const category = mapCategory(text, tags);
    const id = crypto.randomUUID();
    await syncPromptLimit().catch(() => null);
    const list = await addPrompt({
      id,
      title: '',
      titleEn: '',
      translationZh: '',
      content: text,
      tags,
      tagsEn: [],
      category,
      categories: [category],
      syncState: 'pending',
      syncAttemptCount: 0,
      lastSyncAttemptAt: 0,
      syncedAt: 0,
      aiPending: false,
      usageCount: 0,
      showInContextMenu: false,
      contextMenuPinnedAt: 0,
      createdAt: Date.now()
    });
    classifyPrompt(id, text, { list }).catch(() => {});
    showSavedHint(tabId, t(lang, 'promptAdded')).catch(() => {});
    sendEvent('prompt_create', { source, local_prompt_id: id }).catch(() => {});
    return { ok: true, id };
  } catch (e) {
    const lang = await getLang().catch(() => 'zh');
    const code = String(e?.code || e?.message || e);
    const limit = Number(e?.limit || 0) || await getLocalPromptLimit();
    const msg = code === 'LIMIT_EXCEEDED' ? t(lang, 'limitExceeded', { max: limit }) : String(e?.message || e);
    showSavedHint(tabId, t(lang, 'saveFailed', { message: msg })).catch(() => {});
    sendEvent('storage_error', { source, message: msg }).catch(() => {});
    return { ok: false, reason: 'storage_error', message: msg };
  }
}

function ensureSyncAlarm() {
  try {
    chrome.alarms.create(SYNC_ALARM, { periodInMinutes: 1 });
  } catch {}
}

async function runSyncOnce() {
  if (syncing) return;
  syncing = true;
  try {
    await migrateIfNeeded();
    const list = await getPrompts();
    const now = Date.now();
    const pending = list
      .filter((p) => {
        if (p?.aiQuotaExceeded) return false;
        if (p?.syncState === 'blocked') return false;
        if (p?.syncState === 'pending') return true;
        if (!p?.serverPromptId) return true;
        return false;
      })
      .sort((a, b) => (b?.createdAt || 0) - (a?.createdAt || 0));
    let tried = 0;
    for (const p of pending) {
      if (tried >= 3) break;
      if (now - (p?.lastSyncAttemptAt || 0) < 30_000) continue;
      tried += 1;
      const res = await classifyPrompt(p.id, p.content || '').catch(() => ({ ok: false, status: 0, data: { error: 'NETWORK_ERROR' } }));
      if (res?.status === 0 || res?.data?.error === 'NETWORK_ERROR') break;
    }
  } finally {
    syncing = false;
  }
}

chrome.runtime.onInstalled.addListener(() => {
  rebuildContextMenus().catch(() => {});
  ensureSyncAlarm();
  try {
    installPing({ ext_version: chrome.runtime.getManifest().version, platform: navigator.userAgent }).catch(() => {});
  } catch {}
});

chrome.runtime.onStartup?.addListener(() => {
  rebuildContextMenus().catch(() => {});
  ensureSyncAlarm();
});

chrome.storage.onChanged.addListener((changes, area) => {
  if ((area === 'local' || area === 'sync') && (changes?.prompts || changes?.uiState)) {
    rebuildContextMenus().catch(() => {});
  }
});

chrome.alarms?.onAlarm?.addListener((alarm) => {
  if (alarm?.name !== SYNC_ALARM) return;
  runSyncOnce().catch(() => {});
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === ADD_SELECTED_PROMPT_MENU_ID) {
    await addPromptFromText(tab?.id, info.selectionText || '', 'context_menu');
    return;
  }
  if (typeof info.menuItemId === 'string' && info.menuItemId.startsWith(INSERT_PROMPT_MENU_PREFIX)) {
    const lang = await getLang().catch(() => 'zh');
    const promptId = info.menuItemId.slice(INSERT_PROMPT_MENU_PREFIX.length);
    const list = await getPrompts().catch(() => []);
    const item = Array.isArray(list) ? list.find((p) => String(p?.id || '') === promptId) : null;
    if (!item?.content) {
      showSavedHint(tab?.id, t(lang, 'promptNotFound')).catch(() => {});
      return;
    }
    const ok = await insertPromptIntoEditable(tab?.id, item.content || '', typeof info.frameId === 'number' ? info.frameId : -1);
    if (ok) {
      incrementUsage(promptId).catch(() => {});
      showSavedHint(tab?.id, t(lang, 'promptInserted')).catch(() => {});
      sendEvent('prompt_insert', { local_prompt_id: promptId, source: 'context_menu' }).catch(() => {});
    } else {
      showSavedHint(tab?.id, t(lang, 'editableNotFound')).catch(() => {});
    }
  }
});

chrome.commands.onCommand.addListener(async (command) => {
  if (command !== 'add-selected-prompt') return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => (window.getSelection ? window.getSelection().toString() : '')
  });
  await addPromptFromText(tab.id, result || '', 'command');
});

async function openOptionsWithFocus(focusId) {
  const url = chrome.runtime.getURL(`options.html?focus=${encodeURIComponent(String(focusId || ''))}`);
  const match = chrome.runtime.getURL('options.html*');
  try {
    const tabs = await chrome.tabs.query({ url: match });
    if (tabs && tabs.length) {
      const tab = tabs[0];
      await chrome.tabs.update(tab.id, { url, active: true });
      if (tab.windowId) await chrome.windows.update(tab.windowId, { focused: true });
      return;
    }
  } catch {}
  try {
    await chrome.tabs.create({ url, active: true });
  } catch {}
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === 'open_options' && msg?.focusId) {
    openOptionsWithFocus(msg.focusId).catch(() => {});
  }
});
