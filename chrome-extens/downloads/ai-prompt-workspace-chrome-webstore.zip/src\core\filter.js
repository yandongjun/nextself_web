export function computeTagIndex(list) {
  const map = new Map();
  for (const item of list) {
    const ts = Array.isArray(item.tags) ? item.tags : [];
    for (const t of ts) {
      map.set(t, (map.get(t) || 0) + 1);
    }
  }
  return map;
}

function firstLine(s) {
  const t = (s || '').split(/\r?\n/)[0] || '';
  return t.trim();
}

function collectTitleTerms(item, titleAliases) {
  const out = [];
  const title = String(item?.title || '').trim();
  const titleEn = String(item?.titleEn || '').trim();
  const fallback = firstLine(item?.content || '');
  if (title) out.push(title.toLowerCase());
  if (titleEn) out.push(titleEn.toLowerCase());
  if (!title && fallback) out.push(fallback.toLowerCase());
  if (typeof titleAliases === 'function') {
    const aliases = titleAliases(title, titleEn, item);
    if (Array.isArray(aliases)) {
      for (const v of aliases) {
        const s = String(v || '').trim().toLowerCase();
        if (s) out.push(s);
      }
    }
  }
  return out;
}

function parseQuery(q) {
  const raw = (q || '').trim();
  if (!raw) return { tags: [], titles: [], words: [] };
  const parts = raw.split(/\s+/);
  const tags = [];
  const titles = [];
  const words = [];
  for (const p of parts) {
    if (p.startsWith('#')) tags.push(p.slice(1).toLowerCase());
    else if (p.startsWith('@')) titles.push(p.slice(1).toLowerCase());
    else words.push(p.toLowerCase());
  }
  return { tags, titles, words };
}

function collectTagTerms(item, tagAliases) {
  const out = [];
  const tags = Array.isArray(item.tags) ? item.tags : [];
  const tagsEn = Array.isArray(item.tagsEn) ? item.tagsEn : [];
  for (let i = 0; i < tags.length; i += 1) {
    const raw = String(tags[i] || '').trim();
    if (!raw) continue;
    out.push(raw.toLowerCase());
    const dynamicEn = String(tagsEn[i] || '').trim();
    if (dynamicEn) out.push(dynamicEn.toLowerCase());
    if (typeof tagAliases === 'function') {
      const aliases = tagAliases(raw, dynamicEn, item);
      if (Array.isArray(aliases)) {
        for (const v of aliases) {
          const s = String(v || '').trim().toLowerCase();
          if (s) out.push(s);
        }
      }
    }
  }
  return out;
}

function matchAdvanced(item, query, extra = {}) {
  const { tags, titles, words } = parseQuery(query);
  const content = (item.content || '').toLowerCase();
  const its = collectTagTerms(item, extra.tagAliases);
  const titleTerms = collectTitleTerms(item, extra.titleAliases);
  for (const t of tags) {
    if (!its.some((x) => x.includes(t))) return false;
  }
  for (const tt of titles) {
    if (!titleTerms.some((x) => x.includes(tt))) return false;
  }
  for (const w of words) {
    const hit = content.includes(w) || its.some((x) => x.includes(w)) || titleTerms.some((x) => x.includes(w));
    if (!hit) return false;
  }
  return true;
}

export function applyFilter(list, activeCategory, activeTag, keyword, extra = {}) {
  // 统一筛选入口：支持分类（单选）→标签（单选/多选）→关键词（支持 #tag/@title 前缀）→其它维度筛选/排序。
  const k = (typeof keyword === 'string' ? keyword : '').trim().toLowerCase();
  const t = Array.isArray(activeTag) ? '' : (typeof activeTag === 'string' ? activeTag : '').trim();
  const c = (typeof activeCategory === 'string' ? activeCategory : '').trim();
  let out = list;
  if (c) {
    out = out.filter((it) => {
      const cs = Array.isArray(it.categories) ? it.categories : [];
      if (cs.length) return cs.includes(c);
      return (it.category || '') === c;
    });
  }
  if (Array.isArray(activeTag)) {
    const tagsArr = activeTag.filter(Boolean);
    if (tagsArr.length) {
      out = out.filter((it) => {
        const ts = Array.isArray(it.tags) ? it.tags : [];
        return tagsArr.some((x) => ts.includes(x));
      });
    }
  } else if (t) {
    out = out.filter((it) => Array.isArray(it.tags) && it.tags.includes(t));
  }
  if (k) {
    out = out.filter((it) => matchAdvanced(it, k, extra));
  }
  const { recentDays, createdRange, favoriteOnly, sort } = extra;
  if (recentDays) {
    const now = Date.now();
    const span = recentDays * 24 * 3600 * 1000;
    out = out.filter((it) => {
      const ts = it.lastUsedAt || it.createdAt || 0;
      return ts ? (now - ts) <= span : false;
    });
  }
  if (createdRange) {
    const now = new Date();
    let start = 0;
    if (createdRange === 'today') {
      const d = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      start = d.getTime();
    } else if (createdRange === 'week') {
      const d = new Date(now);
      const day = d.getDay() || 7;
      d.setHours(0,0,0,0);
      d.setDate(d.getDate() - (day - 1));
      start = d.getTime();
    } else if (createdRange === 'month') {
      const d = new Date(now.getFullYear(), now.getMonth(), 1);
      start = d.getTime();
    } else if (createdRange === 'year') {
      const d = new Date(now.getFullYear(), 0, 1);
      start = d.getTime();
    }
    if (start) {
      out = out.filter((it) => (it.createdAt || 0) >= start);
    }
  }
  if (favoriteOnly) {
    out = out.filter((it) => !!it.favorite);
  }
  if (sort) {
    if (sort === 'recent') {
      out = out.slice().sort((a,b) => (b.lastUsedAt||0) - (a.lastUsedAt||0));
    } else if (sort === 'created') {
      out = out.slice().sort((a,b) => (b.createdAt||0) - (a.createdAt||0));
    } else if (sort === 'usage') {
      out = out.slice().sort((a,b) => (b.usageCount||0) - (a.usageCount||0));
    }
  }
  return out;
}
