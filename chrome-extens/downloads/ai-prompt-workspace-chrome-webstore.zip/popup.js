import { getPrompts, subscribe, migrateIfNeeded, getUIState, setUIState, ensureTaxonomy, togglePromptInContextMenu } from './src/core/storage.js';
import { applyFilter } from './src/core/filter.js';
import { mountCategoryBar } from './src/components/categoryBar.js';
import { mountSearchBar } from './src/components/searchBar.js';
import { renderList } from './src/components/promptList.js';
import { runTests } from './src/core/tests.js';
import { classifyPrompt } from './src/core/aiClassify.js';
import { categoryLabel, documentLang, getLang, setLang, t, tagLabel, tagSearchTerms, promptTitleLabel, promptTitleSearchTerms } from './src/core/i18n.js';

const ui = {
  searchKeyword: '',
  activeCategory: '',
  list: [],
  categories: []
};

const searchInput = document.getElementById('search-input');
const statusPill = document.getElementById('status-pill');
const categoryBarEl = document.getElementById('category-bar');
const listEl = document.getElementById('list');
const openOptionsBtn = document.getElementById('open-options');
const langToggleBtn = document.getElementById('lang-toggle');
let lastListIds = new Set();
let hiddenNewCount = 0;
let lang = 'zh';

function tt(key, vars) {
  return t(lang, key, vars);
}

function applyTexts() {
  document.documentElement.lang = documentLang(lang);
  document.title = tt('popupTitle');
  searchInput.placeholder = tt('popupSearchPlaceholder');
  openOptionsBtn.textContent = tt('openOptions');
  langToggleBtn.textContent = '中文 / EN';
}

function applyTheme(theme) {
  const dark = theme === 'dark';
  document.body.classList.toggle('dark', dark);
}

function updateStatusPill() {
  let text = '';
  if (hiddenNewCount) text = tt('hiddenResults', { count: hiddenNewCount });
  else if (ui.activeCategory) text = tt('filteredBy', { value: categoryLabel(lang, ui.activeCategory) });
  else if (ui.searchKeyword) text = tt('searchedBy', { value: ui.searchKeyword });
  if (text) {
    statusPill.textContent = text;
    statusPill.classList.add('show');
    statusPill.onclick = () => {
      ui.searchKeyword = '';
      ui.activeCategory = '';
      hiddenNewCount = 0;
      searchInput.value = '';
      render();
    };
    setTimeout(() => {
      statusPill.style.opacity = '0.6';
    }, 2000);
  } else {
    statusPill.textContent = '';
    statusPill.classList.remove('show');
    statusPill.style.opacity = '';
    statusPill.onclick = null;
  }
}

function flashStatus(message) {
  if (!message) return;
  statusPill.textContent = message;
  statusPill.classList.add('show');
  statusPill.style.opacity = '1';
  statusPill.onclick = null;
  clearTimeout(flashStatus.timer);
  flashStatus.timer = setTimeout(() => {
    updateStatusPill();
  }, 1800);
}

function getItemTagLabel(tag, item, index) {
  const tagsEn = Array.isArray(item?.tagsEn) ? item.tagsEn : [];
  const dynamicEn = String(tagsEn[index] || '').trim();
  return tagLabel(lang, tag, dynamicEn);
}

function getItemTitleLabel(item) {
  const base = String(item?.title || '').trim() || String(item?.content || '').split(/\r?\n/)[0]?.trim() || tt('unnamedPrompt');
  return promptTitleLabel(lang, base, item?.titleEn || '');
}

function filterExtra() {
  return {
    tagAliases: (tag, dynamicEn) => tagSearchTerms(tag, dynamicEn),
    titleAliases: (title, titleEn) => promptTitleSearchTerms(title, titleEn)
  };
}

function render() {
  const countMap = new Map();
  const fx = filterExtra();
  for (const c of ui.categories) countMap.set(c, applyFilter(ui.list, c, '', ui.searchKeyword, fx).length);
  const allCount = applyFilter(ui.list, '', '', ui.searchKeyword, fx).length;
  categoryBar.setCounts(countMap, allCount);
  if (ui.activeCategory) categoryBar.setActive(ui.activeCategory);
  const filtered = applyFilter(ui.list, ui.activeCategory, '', ui.searchKeyword, fx);
  if (!filtered.length && ui.list.length) {
    listEl.innerHTML = '';
    const box = document.createElement('div');
    box.style.padding = '12px';
    box.style.border = '1px solid #e5e7eb';
    box.style.borderRadius = '10px';
    box.style.color = '#6b7280';
    box.style.display = 'grid';
    box.style.gap = '10px';
    const title = document.createElement('div');
    title.textContent = tt('noResults');
    const btn = document.createElement('button');
    btn.className = 'btn';
    btn.textContent = tt('clearFilters');
    btn.onclick = () => {
      ui.searchKeyword = '';
      ui.activeCategory = '';
      searchInput.value = '';
      categoryBar.setActive('');
      render();
    };
    box.append(title, btn);
    listEl.append(box);
  } else {
    renderList(listEl, filtered, null, {
      t: tt,
      tagLabel: getItemTagLabel,
      titleLabel: getItemTitleLabel,
      showTranslation: (item) => lang === 'zh' && !!String(item?.translationZh || '').trim(),
      onToggleContextMenuPin: async (item) => {
        const res = await togglePromptInContextMenu(item?.id, !item?.showInContextMenu);
        const nextList = Array.isArray(res?.list) ? res.list : await getPrompts();
        ui.list = nextList;
        const msg = item?.showInContextMenu ? tt('contextMenuUnpinned') : tt('contextMenuPinned');
        flashStatus(res?.removedId ? `${msg} · ${tt('contextMenuOverflowRemoved')}` : msg);
        render();
      }
    });
  }
  updateStatusPill();
  setUIState({ search: ui.searchKeyword, cat: ui.activeCategory, tags: [] });
}

// CategoryBar 固定一级分类
const categoryBar = mountCategoryBar(categoryBarEl, (cat) => {
  ui.activeCategory = cat;
  render();
}, {
  allLabel: () => tt('allCategories'),
  categoryLabel: (value) => categoryLabel(lang, value),
  categories: ui.categories
});

async function loadPopupSettings() {
  const [state, taxonomy] = await Promise.all([
    getUIState(),
    ensureTaxonomy()
  ]);
  ui.categories = Array.isArray(taxonomy?.categories)
    ? taxonomy.categories.map((x) => String(x?.name || '').trim()).filter(Boolean)
    : [];
  if (!ui.categories.length) ui.categories = ['其他'];
  if (ui.activeCategory && !ui.categories.includes(ui.activeCategory)) {
    ui.activeCategory = '';
  }
  categoryBar.setCategories(ui.categories);
  applyTheme(state?.theme || 'light');
  return state || {};
}

mountSearchBar(searchInput, (kw) => {
  ui.searchKeyword = kw;
  render();
}, (kw) => {
  ui.searchKeyword = kw;
  render();
});

openOptionsBtn.onclick = () => {
  if (chrome?.runtime?.openOptionsPage) {
    chrome.runtime.openOptionsPage();
  } else {
    const url = chrome.runtime.getURL('options.html');
    window.open(url, '_blank');
  }
};

langToggleBtn.onclick = async () => {
  lang = await setLang(lang === 'zh' ? 'en' : 'zh');
  applyTexts();
  render();
};

(async function init() {
  try {
    lang = await getLang();
    applyTexts();
    await migrateIfNeeded();
    ui.list = await getPrompts();
    lastListIds = new Set(ui.list.map((p) => p?.id).filter(Boolean));
    const state = await loadPopupSettings();
    if (state) {
      ui.searchKeyword = state.search || '';
      ui.activeCategory = state.cat || '';
    }
    const retryTargets = ui.list
      .filter((p) => !p.serverPromptId && !p.aiQuotaExceeded && (p.aiPending || p.aiError))
      .slice(0, 5);
    for (const p of retryTargets) {
      classifyPrompt(p.id, p.content || '').catch(() => {});
    }
    render();
    subscribe((list2) => {
      const next = Array.isArray(list2) ? list2 : [];
      const added = [];
      for (const p of next) {
        const id = p?.id;
        if (id && !lastListIds.has(id)) added.push(id);
      }
      lastListIds = new Set(next.map((p) => p?.id).filter(Boolean));
      if (added.length) {
        const visible = applyFilter(next, ui.activeCategory, '', ui.searchKeyword, filterExtra());
        const visibleIds = new Set(visible.map((p) => p.id));
        hiddenNewCount = added.filter((id) => !visibleIds.has(id)).length;
      } else {
        hiddenNewCount = 0;
      }
      ui.list = list2;
      render();
    });
    chrome.storage.onChanged.addListener(async (changes, area) => {
      if (area !== 'local') return;
      if (changes.uiState || changes.taxonomy) {
        const state2 = await loadPopupSettings();
        ui.activeCategory = state2?.cat || ui.activeCategory;
        render();
      }
    });
    window.runPromptCollectorTests = runTests;
  } catch (e) {
    const msg = String(e?.message || e);
    listEl.innerHTML = `<div style="padding:12px;color:#b91c1c">${tt('popupReadError', { message: msg })}</div>`;
    statusPill.textContent = tt('popupReadErrorShort');
    statusPill.classList.add('show');
  }
})();
